import React, { useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, Card, Text, Provider, Snackbar } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils';
import {myStyles, gradientColors, snackbarColors} from '../utils/myStyles'

export default function ShopScreen(navigation) {

  const itemsPrices = {'OffensiveRestore' : 30, 'DoubleReward' : 10, 'DoDailyChallenge' : 100};
  const [userCoins, setUserCoins] = useState(1000); 
  const [successfulBuy, setSuccessfulBuy] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);

  const handleBuy = (item) => {
    if(userCoins >= itemsPrices[item]){
      setUserCoins(userCoins - itemsPrices[item]);
      setSuccessfulBuy(true);
    }
    else {
      setSuccessfulBuy(false);
    }
    setSnackbarVisible(true);

  };

  return (
    <Provider theme={colorThemes['red']['dark']}>
    <LinearGradient
        colors={gradientColors}
        style={styles.background} >
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}>
            <Text style={[myStyles.header,{alignSelf: 'center'}]} variant="displayLarge">Loja de Items</Text>
            <Card style={styles.card} mode={'elevated'}>
              <Card.Cover source={require('../assets/streak.png')} />
              <Card.Title title="Restaurar Ofensiva" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item usado automaticamente para manter a ofensiva por um dia a mais caso ela seja perdida. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Custo: {itemsPrices['OffensiveRestore']} moedas
                </Text>
              </Card.Content>
              <Card.Actions>
                <Button style={styles.button} onPress={() => {handleBuy('OffensiveRestore')}}
                 mode="contained-tonal" buttonColor={"#DB2323"} 
                 icon={({ size, color }) => (
                  <MaterialIcons name="shopping-cart"  size={size} color={'white'} />
                )}>
                  Comprar
                </Button>
              </Card.Actions>
            </Card>
            <Card style={styles.card} mode={'elevated'}>
              <Card.Cover source={require('../assets/daily.png')} />
              <Card.Title title="Fazer desafio diário perdido" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item que quando usado permite fazer o desafio diário de um dia em que ele não foi feito. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Custo: {itemsPrices['DoDailyChallenge']} moedas
                </Text>
              </Card.Content>
              <Card.Actions>
                <Button style={styles.button} onPress={() => {handleBuy('DoDailyChallenge')}}
                 mode="contained-tonal" buttonColor={"#DB2323"}
                 icon={({ size, color }) => (
                  <MaterialIcons name="shopping-cart"  size={size} color={'white'} />
                )}>
                  Comprar
                </Button>
              </Card.Actions>
            </Card>
            <Card style={styles.card} mode={'elevated'} theme={{ colors: { primary: 'green' } }}>
              <Card.Cover source={require('../assets/double.png')} />
              <Card.Title  title="Dobrar Recompensas" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item que quando usado permite dobra o ganho de moedas de todos os exercícios feitos por um dia. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Custo: {itemsPrices['DoubleReward']} moedas
                </Text>
              </Card.Content>
              <Card.Actions>
                <Button style={styles.button} onPress={() => {handleBuy('DoubleReward')}} 
                mode="contained-tonal" buttonColor={"#DB2323"}
                icon={({ size, color }) => (
                  <MaterialIcons name="shopping-cart"  size={size} color={'white'} />
                )}>
                  Comprar
                </Button>
              </Card.Actions>
            </Card>
      </ScrollView>
      <Snackbar
          visible={snackbarVisible}
          onDismiss={() => setSnackbarVisible(false)}
          action={{
            label: 'Ok',
            onPress: () => {
              setSnackbarVisible(false)
            },
          }}
          duration={Snackbar.DURATION_MEDIUM}
          style={{ backgroundColor: successfulBuy ? snackbarColors['success'] : snackbarColors['error'],
          position: 'absolute', bottom: 0}}
          theme={successfulBuy ? colorThemes['green']['dark'] : colorThemes['red']['dark']}
        >
          {successfulBuy ? 'Compra realizada com sucesso' : 
          'Erro ao efetuar compra, moedas insuficientes!' }
        </Snackbar>
    </LinearGradient>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  content: {
    padding: 4,
    marginHorizontal: 25,
  },
  button: {
    margin: 4,
  },
  card: {
    margin: 4,
  },
  cost :{
    fontWeight: 'bold',
  },
});
