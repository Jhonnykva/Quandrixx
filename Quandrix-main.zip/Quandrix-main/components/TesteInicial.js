import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {myStyles, gradientColors} from '../utils/myStyles';
import {Button, Text} from 'react-native-paper';

export default function LevelTestScreen({ navigation, route }) {
  const { module } = route.params;
  const handleContinue = () => {
    navigation.navigate('Teste', {
      module: module
    }); 
  };

  const handleBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <View style={styles.content}>
          <Text style={myStyles.header} variant="displayLarge">Teste Inicial</Text>
          <Text style={styles.explanationText}>
            Como é a primeira vez que você está acessando esse módulo, 
            será feito um teste de nivelamento para determinar o seu nível atual. 
            Serão apresentadas 6 perguntas, 2 fáceis, 2 médias e 2 difíceis. Quando
            estiver pronto clique em "Continuar".
          </Text>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleContinue}
              style={styles.continueButton}
              labelStyle={{fontFamily: 'RobotoMono'}}
            >
              Continuar
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleBack}
              style={styles.goBackButton}
              labelStyle={{marginHorizontal: 37, fontFamily: 'RobotoMono'}}
            >
             Voltar
          </Button>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '80%',
    paddingVertical:30,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  explanationText: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
    marginHorizontal: 30,
    fontFamily: 'RobotoMono',
  },
  continueButton: {
    margin: 4,
    background: 'blue',
    borderColor: 'black',
    borderWidth: 1
  },
  goBackButton: {
    margin: 4,
    backgorund: 'blue',
    marginHorizontal: 100,
    borderColor: 'black',
    borderWidth: 1
  },
  titleContainer: {
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
  },
});
