import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {gradientColors} from '../utils/myStyles'
import {Button, Text, Provider, Surface, ActivityIndicator} from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils/index'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage';

import { checkDoubleReward, QuestionContainer, TextAnswerContainer, RightAnswerFeedback, WrongAnswerFeedback } from '../utils/QuestionComponents';

export default function ChallengeScreen({route, navigation }) {
  const { day } = route.params;
  const [question, setQuestion] = useState(null);
  const [correctAnswer, setCorrectAnswer] = useState(null);
  const [student, setStudent] = useState({});

  const [userAnswer, setUserAnswer] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [rightAnswer, setRightAnswer] = useState(null);

  const [doubleRewardActive, setDoubleRewardActive] = useState(false);

  const [dailyChallengeDone, setDailyChallengeDone] = useState(false);

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid )).then( (snapshot) => {
      if(snapshot.exists()){
        setStudent(snapshot.val());
        console.log(snapshot.val().desafios);
        if(!('desafios' in snapshot.val()) || !(snapshot.val().desafios.includes(day))){
        setDailyChallengeDone(false);
        get(child(dbRef, 'questoes/desafioDiario/' + day)).then((snapshot2) => {
            const stRef = storageRef(getStorage(app), 'questoes/desafiosDiarios/' + snapshot2.val().id + '.PNG');
            getDownloadURL(stRef).then((url) => {
            setQuestion(url);
            setCorrectAnswer(snapshot2.val().resposta);
            })
        })
        }
        else{
        setDailyChallengeDone(true);
        }
      }
      else {
        console.log("Error: snapshot doesn't exists!");
      }
    }).catch((error) => {
      console.log("Error retrieving from Firebase!");
    })
  }, [auth.currentUser, dbRef]);

  useEffect(() => {
    const fetchDoubleReward = async () => {
      const result = await checkDoubleReward();
      setDoubleRewardActive(result);
    };
    fetchDoubleReward();
  }, []);

  const handleConfirm = () => {

    if(auth.currentUser === null){
      console.error("Error: null user!");
      return;
    }
    
    const uid = auth.currentUser.uid;
    const updates = {};

    if('desafios' in student){
        const challengesDone = student.desafios.concat(day);
        updates['/estudantes/' + uid + '/desafios'] = challengesDone;
    }
    else{
        updates['/estudantes/' + uid + '/desafios'] = [challengesDone];
    }

    if(userAnswer === correctAnswer) {
        setRightAnswer(true);
        if(doubleRewardActive){
            updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 5);
        }
        else {
            updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 10);
        }
    }
    else {
        setRightAnswer(false);
    }
    
    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      setSuccessfulRegister(false);
      setSnackbarMessage("Erro ao atualizar o banco de dados!");
    })

    setConfirmed(true);
  };

  const handleGoBack = () => {
    navigation.navigate('Main');
  }

  return (
    <Provider theme={
    rightAnswer === null
      ? colorThemes['blue']['light']
      : rightAnswer === true
      ? colorThemes['green']['light']
      : colorThemes['red']['light']
    }>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        {(question) && <Surface style={styles.container} elevation={0}>
          <QuestionContainer question={question} confirmed={confirmed} rightAnswer={rightAnswer}/>
          {doubleRewardActive && <Text style={{textAlign: 'right', marginRight: '5%', color: 'yellow', fontFamily: 'Orbitron'}}>2X Moedas‼️</Text>}
          <TextAnswerContainer 
              confirmed={confirmed} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          {rightAnswer === true && 
            <RightAnswerFeedback 
              doubleRewardActive={doubleRewardActive}
              baseCoinReward={5}
              progress={false}
            />
          }
          {rightAnswer === false && 
            <WrongAnswerFeedback/>
          }
          {(userAnswer!= null && confirmed === false) &&
          <Button
              mode="contained-tonal"
              buttonColor={"#66FF66"}
              onPress={handleConfirm}
              style={styles.confirmButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="done" size={size} color={color} />
              )}
          >
            Confirmar
          </Button>}
          {confirmed === true && <View style={styles.row}> 
            <Button
                mode="contained-tonal"
                buttonColor={"#17B0E0"}
                onPress={handleGoBack}
                style={styles.goBackButton}
                labelStyle={styles.buttonText}
                icon={({ size, color }) => (
                    <MaterialIcons name="undo" size={size} color={color} />
                )}
            >
                Voltar
            </Button>
          </View>
          }
        </Surface> }
        {dailyChallengeDone && <Surface style={styles.container} elevation={0}>
          <Text style={styles.noQuestionsText}>
            Desafio diário já feito! Volte amanhã.
          </Text>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={styles.goBackButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
        </Surface>}
        {(!question && !dailyChallengeDone) && <Surface style={styles.container} elevation={0}>
          <ActivityIndicator animating={true} size='large'/>
        </Surface>}
      </LinearGradient>
    </Provider>
  );
}

const styles = StyleSheet.create({
 container: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '85%',
    height: '85%',
    paddingTop:20,
    paddingBottom:20,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmButton: {
    marginHorizontal: 15,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
  },
  goBackButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
    alignSelf: 'center',
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingHorizontal: 0,
    paddingVertical: 2,
    marginHorizontal: 10,
  },
  text: {
    paddingLeft: 8,
    paddingTop: 9,
  },
  question: {
    flex: 1,
  },
  noQuestionsText: {
    color: 'rgba(255,255,255,0.45)',
    fontFamily: 'RobotoMono',
    fontSize: 20,
    alignSelf: 'center',
    margin: '15%'
  }
});
