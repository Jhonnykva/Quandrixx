import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, Card, Text, Provider, Snackbar } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils';
import {myStyles, gradientColors, snackbarColors} from '../utils/myStyles'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";

import AsyncStorage from '@react-native-async-storage/async-storage';
import { DatePickerModal } from 'react-native-paper-dates';
import { activateOffensive, checkOffensiveStatus } from '../utils/offensive';
import { checkDoubleReward } from '../utils/doubleReward';


export default function Inventory({navigation}) {

  const [offensiveRestoreQtd, setOffensiveRestoreQtd] = useState(0);
  const [doubleRewardQtd, setDoubleRewardQtd] = useState(0);
  const [doDailyChallengeQtd, setDoDailyChallengeQtd] = useState(1);

  const [successfulUse, setSuccessfulUse] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);

  const [doubleRewardActive, setDoubleRewardActive] = useState(false);

  const [date, setDate] = useState(null);
  const [show, setShow] = useState(false);

  const[disabledDates, setDisabledDates] = useState([]);
  const startDate = new Date(2023, 9, 1);
  const endDate = new Date();

  const [offensiveValue, setOffensiveValue] = useState(0);
  const [offensiveStatus, setOffensiveStatus] = useState(null);

  const parseYYMMDDToDate = (dateString) => {
    const [year, month, day] = dateString.split('-').map(Number);
    const parsedDate = new Date(year, month - 1, day);
    return parsedDate;
  }

  const formatDateToYYMMDD = (date) => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); 
    const day = date.getDate().toString().padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    return formattedDate;
  }

  const onDismissSingle = React.useCallback(() => {
    setShow(false);
  }, [setShow]);

  const onConfirmSingle = React.useCallback(
    (params) => {
      setShow(false);
      setDate(params.date);
      setDoDailyChallengeQtd(doDailyChallengeQtd-1);

      if(auth.currentUser === null){
        console.error("Error: null user!");
        return;
      }
      const uid = auth.currentUser.uid;
      const updates = {};
      updates['/estudantes/' + uid + '/itens/desafio'] = (doDailyChallengeQtd - 1);
      update(dbRef, updates).then( (update) => {
      }).catch((error) => {
        setSuccessfulUse(false);
        console.error("Erro ao guardar valor no Firebase");
      })
      navigation.navigate('Desafio', {
        day: formatDateToYYMMDD(params.date),
      });
      
      setSuccessfulUse(true);
      setSnackbarVisible(true);
    },
    [setShow, setDate, doDailyChallengeQtd]
  );

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid)).then( (snapshot) => {
      if(snapshot.exists()){
        setDoDailyChallengeQtd(snapshot.val().itens.desafio);
        setDoubleRewardQtd(snapshot.val().itens.moedas);
        setOffensiveRestoreQtd(snapshot.val().itens.ofensiva);
        get(child(dbRef, 'questoes/desafioDiario')).then((snapshot2) => {
            const allChallengesString = Object.keys(snapshot2.val());
            const allChallengesDate = allChallengesString.map(parseYYMMDDToDate);
            if('desafios' in snapshot.val()){
              const challengesDoneString = snapshot.val().desafios;
              const challengesDoneDate = challengesDoneString.map(parseYYMMDDToDate);
              const filteredChallenges = allChallengesDate.filter((date2) => {
                return !challengesDoneDate.some((date1) => date1.getTime() === date2.getTime());
              });
              const dateRange = [];
              for (let date = startDate; date <= endDate; date.setDate(date.getDate() + 1)) {
                if (!filteredChallenges.some((filteredDate) => filteredDate.getTime() === date.getTime())) {
                  dateRange.push(new Date(date)); 
                }
              }
              setDisabledDates(dateRange);
            }
        }).catch((error) => {
          console.log("Error retrieving information from database!");
        })
        
      }
      else {
        setDoDailyChallengeQtd(0);
        setDoubleRewardQtd(0);
        setOffensiveRestoreQtd(0);
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
  }, [auth.currentUser, dbRef]);

  useEffect(() => {
    const fetchDoubleReward = async () => {
      const result = await checkDoubleReward();
      setDoubleRewardActive(result);
    };
    fetchDoubleReward();
  }, []);

  useEffect(() => {
    const fetchOffensive = async () => {
      const {value, status} = await checkOffensiveStatus();
      setOffensiveValue(value);
      setOffensiveStatus(status);
      console.log(status);
    };
    fetchOffensive();
  }, []);

  const handleUseOffensiveRestore = () => {
    if(offensiveRestoreQtd > 0){
      activateOffensive(offensiveValue);
      if(auth.currentUser === null){
        console.error("Error: null user!");
        return;
      }
      
      const uid = auth.currentUser.uid;
      const updates = {};
      updates['/estudantes/' + uid + '/itens/ofensiva'] = (offensiveRestoreQtd - 1);
  
      update(dbRef, updates).then( (update) => {
      }).catch((error) => {
        setSuccessfulUse(false);
        console.error("Erro ao guardar valor no Firebase");
      })
      setOffensiveRestoreQtd(offensiveRestoreQtd - 1);
      setOffensiveStatus('Active');
      setSuccessfulUse(true);
    }
    else{
      setSuccessfulUse(false);
    }
    setSnackbarVisible(true);
  };

  const handleUseDoubleReward = () => {
    if(doubleRewardQtd > 0){
      const expirationTimeInHours = 24;
      const expirationTimestamp = Date.now() + expirationTimeInHours * 60 * 60 * 1000;
      AsyncStorage.setItem('doubleReward', JSON.stringify({value: true, expiration: expirationTimestamp})).then(() => {
        console.log("Item usado com sucesso!");
      }).catch((error) => {
        console.error("Error ao usar o AsyncStorage");
        return;
      })

      if(auth.currentUser === null){
        console.error("Error: null user!");
        return;
      }
      
      const uid = auth.currentUser.uid;
      const updates = {};
      updates['/estudantes/' + uid + '/itens/moedas'] = (doubleRewardQtd - 1);
  
      update(dbRef, updates).then( (update) => {
      }).catch((error) => {
        setSuccessfulUse(false);
        console.error("Erro ao guardar valor no Firebase");
      })
      setDoubleRewardActive(true);
      setDoubleRewardQtd(doubleRewardQtd - 1);
      setSuccessfulUse(true);
    }
    else{
      setSuccessfulUse(false);
    }
    setSnackbarVisible(true);
  };
  
  const handleDoDailyChallenge = () => {
    if(doDailyChallengeQtd > 0){
      setShow(true);
    }
    else{
      setSuccessfulUse(false);
      setSnackbarVisible(true);
    }
    
  };
  

  return (
    <Provider theme={colorThemes['blue']['dark']}>
    <LinearGradient
        colors={gradientColors}
        style={styles.background} >
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}>
            <Text style={[myStyles.header,{alignSelf: 'center'}]} variant="displayLarge">Inventário</Text>
            <Card style={styles.card} mode={'elevated'}>
              <Card.Cover source={require('../assets/streak.png')} />
              <Card.Title title="Restaurar Ofensiva" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item usado automaticamente para manter a ofensiva por um dia a mais caso ela seja perdida. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Quantidade: {offensiveRestoreQtd}
                </Text>
              </Card.Content>
              <Card.Actions>
              {(offensiveStatus === 'Active' || offensiveStatus === 'Refillable') && 
              <Text style={{marginRight: '5%', color: 'red', fontFamily: 'RobotoMono', fontSize: 13}}>Ofensiva ativa! 🔥</Text>}
              {(offensiveStatus === 'Restorable') && 
              <Text style={{marginRight: '5%', color: 'yellow', fontFamily: 'RobotoMono', fontSize: 13}}>Ofensiva restaurável! ✨</Text>}
              {(offensiveStatus === 'Expired') && 
              <Text style={{marginRight: '5%', color: 'cyan', fontFamily: 'RobotoMono', fontSize: 13}}>Ofensiva expirada! 🧊</Text>}
                <Button style={styles.button} onPress={handleUseOffensiveRestore} mode="contained-tonal"
                 buttonColor={"#2348DB"}
                 icon={({ size, color }) => (
                  <MaterialIcons name="local-fire-department"  size={size} color={'white'} />
                )}
                disabled={offensiveStatus !== 'Restorable'}>
                  Usar
                </Button>
              </Card.Actions>
            </Card>
            <Card style={styles.card} mode={'elevated'}>
              <Card.Cover source={require('../assets/daily.png')} />
              <Card.Title title="Fazer desafio diário perdido" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item que quando usado permite fazer o desafio diário de um dia em que ele não foi feito. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Quantidade: {doDailyChallengeQtd}
                </Text>
              </Card.Content>
              <Card.Actions>
                <Button style={styles.button} onPress={handleDoDailyChallenge} mode="contained-tonal"
                 buttonColor={"#2348DB"}
                 icon={({ size, color }) => (
                  <MaterialIcons name="today"  size={size} color={'white'} />
                )}>
                  Usar
                </Button>
              </Card.Actions>
            </Card>
            <DatePickerModal
              locale={'en-UK'}
              mode="single"
              visible={show}
              onDismiss={onDismissSingle}
              date={date}
              onConfirm={onConfirmSingle}
              validRange={{
                startDate: startDate,
                endDate: endDate,
                disabledDates: disabledDates}}
            />
            <Card style={styles.card} mode={'elevated'} theme={{ colors: { primary: 'green' } }}>
              <Card.Cover source={require('../assets/double.png')} />
              <Card.Title  title="Dobrar Recompensas" />
              <Card.Content>
                <Text variant="bodyMedium">
                  Item que quando usado permite dobra o ganho de moedas de todos os exercícios feitos por um dia. {'\n'}{'\n'}
                </Text>
                <Text style={styles.cost}>
                  Quantidade: {doubleRewardQtd} 
                </Text>
              </Card.Content>
              <Card.Actions>
              {doubleRewardActive && <Text style={{marginRight: '5%', color: 'yellow', fontFamily: 'Orbitron'}}>2X Moedas‼️</Text>}
                <Button style={styles.button} onPress={handleUseDoubleReward} mode="contained-tonal" 
                buttonColor={"#2348DB"}
                icon={({ size, color }) => (
                  <MaterialIcons name="attach-money"  size={size} color={'white'} />
                )}
                disabled={doubleRewardActive}>
                  Usar
                </Button>
              </Card.Actions>
            </Card>
      </ScrollView>
      <Snackbar
          visible={snackbarVisible}
          onDismiss={() => setSnackbarVisible(false)}
          action={{
            label: 'Fechar',
            onPress: () => {
              setSnackbarVisible(false)
            },
          }}
          duration={Snackbar.DURATION_MEDIUM}
          style={{ backgroundColor: successfulUse ? snackbarColors['success'] : snackbarColors['error'], 
          position: 'absolute', bottom: 0}}
          theme={successfulUse ? colorThemes['green']['dark'] : colorThemes['red']['dark']}
        >
          {successfulUse ? 'Item utilizado com sucesso' : 
          'Erro ao utilizar item, items insuficientes!' }
        </Snackbar>
    </LinearGradient>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  content: {
    padding: 4,
    marginHorizontal: 25,
  },
  button: {
    margin: 4,
  },
  card: {
    margin: 4,
  },
  cost :{
    fontWeight: 'bold',
  },
});
