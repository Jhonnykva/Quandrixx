import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradientColors} from '../utils/myStyles'
import {Button, Text, Provider, Surface, ActivityIndicator} from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils/index'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage';

import { QuestionContainer, OptionAnswerContainer, TextAnswerContainer, RightAnswerFeedback, WrongAnswerFeedback } from '../utils/QuestionComponents';
import { checkDoubleReward } from '../utils/doubleReward';
import { questionsToAdvance } from '../utils/constants';

export default function QuestionScreen({ navigation }) {
  const [question, setQuestion] = useState(null);
  const options = ['A', 'B', 'C', 'D', 'E'];
  const [correctAnswer, setCorrectAnswer] = useState(null);
  const [student, setStudent] = useState({});
  const [noQuestions, setNoQuestions] = useState(false);
  const [questionType, setQuestionType] = useState("fechada");

  const [userAnswer, setUserAnswer] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [rightAnswer, setRightAnswer] = useState(null);

  const [doubleRewardActive, setDoubleRewardActive] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [questionLevel, setQuestionLevel] = useState(null);
  const [questionModule, setQuestionModule] = useState(null);

  const countHowManyQuestionsWrong = (type, wrongQuestions) => {
    return wrongQuestions.filter(item => item.includes(type)).length;
  }

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid )).then( (student) => {
      if(student.exists()){
        setStudent(student.val());
        if('questoesErradas' in student.val()){
          const wrongQuestions = student.val()['questoesErradas'];
          console.log(wrongQuestions);
          const [selectedQuestionPath, selectedQuestionId] = wrongQuestions[questionIndex].split('@');
          const [title, module, level] = selectedQuestionPath.split('/');
          get(child(dbRef, selectedQuestionPath + '/' + selectedQuestionId)).then( (question) => {
            if(question.exists()){
              const stRef1 = storageRef(getStorage(app), selectedQuestionPath + '/' + selectedQuestionId + '.PNG');
              getDownloadURL(stRef1).then((url) => {
                setQuestion(url);
                setCorrectAnswer(question.val().resposta);
                setQuestionType(question.val().tipo);
                setQuestionLevel(level);
                setQuestionModule(module);
              }).catch((error) => {
                console.log("Error: downloading image!");
                console.error(error.code);
              })
            }
            else {
              console.log("Error: snapshot doesn't exists!");
            }
          }).catch((error) => {
            console.log("Error retrieving information from database!");
          })   
        }
        else {
          setNoQuestions(true);
          return;
        }        
      }
      else {
        console.log("Error: snapshot doesn't exists!");
      }
    }).catch((error) => {
      console.log("Error retrieving from Firebase!");
    })
  }, [auth.currentUser, dbRef]);

  useEffect(() => {
    const fetchDoubleReward = async () => {
      const result = await checkDoubleReward();
      setDoubleRewardActive(result);
    };
    fetchDoubleReward();
  }, [questionIndex]);

  const handleConfirm = () => {

    if(auth.currentUser === null){
      console.error("Error: null user!");
      return;
    }
    
    const uid = auth.currentUser.uid;
    const updates = {};


    if (userAnswer === correctAnswer) {
      setRightAnswer(true);
      if(doubleRewardActive){
        updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 2);
      }
      else {
        updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 1);
      }
      student.questoesErradas.splice(questionIndex, 1);
      updates['/estudantes/' + uid + '/questoesErradas'] = student.questoesErradas; 
      if(questionLevel === "facil"){
        if(!student["dificuldades"][questionModule]["medio"]){
          if((student["questoes"][questionModule][questionLevel].length - countHowManyQuestionsWrong((questionModule + '/' + questionLevel), student["questoesErradas"])) === questionsToAdvance){
            updates['/estudantes/' + uid + '/dificuldades/' + questionModule + '/medio'] = true;
          }
        }
      }
      if(questionLevel === "medio"){
        if(!student["dificuldades"][questionModule]["dificil"]){
          if((student["questoes"][questionModule][questionLevel].length - countHowManyQuestionsWrong((questionModule + '/' + questionLevel), student["questoesErradas"])) === questionsToAdvance){
            updates['/estudantes/' + uid + '/dificuldades/' + questionModule + '/dificil'] = true;
          }
        }
      }

    } else {
      setQuestionIndex(questionIndex + 1);
      setRightAnswer(false);
    }
    
    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      setSuccessfulRegister(false);
      setSnackbarMessage("Erro ao atualizar o banco de dados!");
    })

    setConfirmed(true);
  };

  const handleGoBack = () => {
    navigation.goBack();
  }

  const handleContinue = () => {
    if(questionIndex >= student['questoesErradas'].length){
      setNoQuestions(true);
      return;
    }
    console.log(student['questoesErradas'].length)
    console.log(questionIndex);
    const wrongQuestions = student['questoesErradas'];
    const [selectedQuestionPath, selectedQuestionId] = wrongQuestions[questionIndex].split('@');
    get(child(dbRef, selectedQuestionPath + '/' + selectedQuestionId)).then( (question) => {
      if(question.exists()){
        const stRef1 = storageRef(getStorage(app), selectedQuestionPath + '/' + selectedQuestionId + '.PNG');
        getDownloadURL(stRef1).then((url) => {
          setQuestion(url);
          setCorrectAnswer(question.val().resposta);
          setQuestionType(question.val().tipo);
        }).catch((error) => {
          console.log("Error: downloading image!");
          console.error(error.code);
        })
      }
      else {
        console.log("Error: snapshot doesn't exists!");
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
    setConfirmed(false); 
    setRightAnswer(null);
    setUserAnswer(null);  
  }

  return (
    <Provider theme={
    rightAnswer === null
      ? colorThemes['blue']['light']
      : rightAnswer === true
      ? colorThemes['green']['light']
      : colorThemes['red']['light']
    }>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        {(!noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <QuestionContainer 
            question={question} 
            confirmed={confirmed} 
            rightAnswer={rightAnswer} 
          />
          {doubleRewardActive && 
            <Text style={{textAlign: 'right', marginRight: '5%', color: 'yellow', fontFamily: 'Orbitron'}}>2X Moedas‼️</Text>
          }
          {questionType === "fechada" &&
            <OptionAnswerContainer 
              confirmed={confirmed} 
              options={options} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {questionType === "aberta" && 
            <TextAnswerContainer 
              confirmed={confirmed} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {rightAnswer === true && 
            <RightAnswerFeedback 
              doubleRewardActive={doubleRewardActive}
              baseCoinReward={1}
              progress={true}  
            />
          }
          {rightAnswer === false && 
            <WrongAnswerFeedback
              auxiliarText={"Tente novamente depois!"}
            />
          }
          {(userAnswer!=null && confirmed === false) &&
          <Button
              mode="contained-tonal"
              buttonColor={"#66FF66"}
              onPress={handleConfirm}
              style={styles.confirmButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="done" size={size} color={color} />
              )}
          >
            Confirmar
          </Button>  }
          {confirmed === true && <View style={styles.row}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleContinue}
              style={styles.continueButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="play-arrow" size={size} color={color} />
              )}
          >
            Continuar
          </Button>  
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={styles.goBackButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
          </View>
          }
        </Surface> }
        {(noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <Text style={styles.noQuestionsText}>
            Opa, parece que você já refez todos os exercícios que errou!. Tente fazer novos exercícios
            dentro dos módulos. Não se procupe, se errou algum novamente basta entrar novamente na página.
          </Text>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={[styles.goBackButton, {alignSelf: 'center'}]}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
        </Surface>}
        {(!question) && <Surface style={styles.container} elevation={0}>
          <ActivityIndicator animating={true} size='large'/>
        </Surface>}
      </LinearGradient>
    </Provider>
  );
}

const styles = StyleSheet.create({
 container: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '85%',
    height: '85%',
    paddingTop:20,
    paddingBottom:20,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmButton: {
    marginHorizontal: 15,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
  },
  goBackButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
  },
  continueButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'left',
    paddingHorizontal: 0,
    paddingVertical: 2,
    marginHorizontal: 10,
  },
  text: {
    paddingLeft: 8,
    paddingTop: 9,
  },
  question: {
    flex: 1,
  },
  noQuestionsText: {
    color: 'rgba(255,255,255,0.45)',
    fontFamily: 'RobotoMono',
    fontSize: 20,
    alignSelf: 'center',
    margin: '15%'
  }
});
