import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, List, useTheme, TextInput, Text, Surface } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors} from '../utils/myStyles';
import { useFocusEffect } from '@react-navigation/native';

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";

export default function Dificuldade({ route, navigation }) {

  const {module} = route.params;
  const [enabledLevels, setEnabledLevels] = useState({
    "facil": false,
    "medio": false, 
    "dificil": false,
  })

  useFocusEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid + '/dificuldades/' + module )).then( (dificulties) => {
      if(dificulties.exists()){
        setEnabledLevels({
          "facil" : dificulties.val().facil,
          "medio" : dificulties.val().medio,
          "dificil" : dificulties.val().dificil,
        });
      }
      else{
        console.log("Erro: snapshot não existe!");
      }
    }).catch((error) => {
      console.log(error);
    })
  })

  const handleBackToModulo = () => {
    navigation.goBack();
  };

  const handleQuestao = (level) => {
    navigation.navigate('Questao', {
      level: level,
      module: module,
      day: "",
    }); 
  };

  const handleFundamentacao = (level) => {
    navigation.navigate('Fundamentacao',{
      level: level,
      module: module,
    });
  }

  const handleTeste = () => {
    navigation.navigate('TesteInicial'); 
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <Surface style={styles.modules} elevation={0}>
          <Text style={myStyles.header} variant="displayLarge"> Dificuldades </Text>
          <View style={styles.buttons}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleQuestao('facil')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              disabled={!enabledLevels["facil"]}
            >
              🟢 Fácil {!enabledLevels['facil'] && '🔒'}
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleQuestao('medio')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              disabled={!enabledLevels["medio"]}
            >
             🟡 Médio {!enabledLevels['medio'] && '🔒'}
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleQuestao('dificil')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              disabled={!enabledLevels["dificil"]}
            >
              🔴 Difícil {!enabledLevels['dificil'] && '🔒'}
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleFundamentacao}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono', fontSize: 12}}
              icon={({ size, color }) => (
                <MaterialIcons name="auto-stories" size={size} color={color} />
            )}
          >
            Fundamentação Teórica
          </Button>
          <Button
            mode="contained-tonal"
            buttonColor={"#17B0E0"}
            onPress={handleBackToModulo}
            style={styles.button}
            icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
            )}
          >
            Voltar
          </Button>   
          </View>
        </Surface>
        </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  modules: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '80%',
    paddingVertical:30,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttons: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    width: '85%',
  },
  button: {
    margin: 4,
    borderColor: 'black',
    borderWidth: 1
  },
  theoryButton: {

  }
});
