import {useState, useEffect} from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, List, useTheme, TextInput, Text, ActivityIndicator,Title, Divider, Provider } from 'react-native-paper';
import {myStyles, gradientColors} from '../utils/myStyles'
import { colorThemes } from '../utils';

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";



export default function ContentFundamentation({route,  navigation }) {

  const [expanded, setExpanded] = useState(false);
  const {module, tema, content} = route.params;
  const [string, setString] = useState('');


  const _handlePress = () => {
    setExpanded(!expanded);
  };

  const handleGoBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    get(child(dbRef, 'fundamentacao/'+module+'/'+tema+'/'+content+'/')).then((snapshot) => {
        if (snapshot.exists()) {
        console.log(snapshot.val());
        setString(snapshot.val());
        } else {
        console.log("No data available");
        }
    }).catch((error) => {
        console.error(error);
    });
  }, []);

  return (
    <Provider theme={colorThemes['cyan']['dark']}>
      <View style={styles.container}>
        <LinearGradient
          colors={gradientColors}
          style={styles.background}
        >
          <List.Section title={module} titleStyle={myStyles.title}>
            <TouchableOpacity style={styles.goBackButton} onPress={handleGoBack}>
              <Text style={styles.goBackText}>Voltar</Text>
            </TouchableOpacity>

            <View style={styles.dataView}>
                <Text style={styles.dataText}>{string}</Text>
            </View>
            
          </List.Section>
        </LinearGradient>
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  accordionTitle: {
    color: 'white',
    fontFamily: 'RobotoMono',
  },
  itemTitle: {
    color: 'white',
  },
    goBackButton: {
    marginBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 20,
  },
  dataText:{
    flex: 1,
    color: 'white',
    fontSize: 20,
    margin: 30 , 
  },
  goBackText: {
    fontSize: 16,
    color: 'white',
  },
});
