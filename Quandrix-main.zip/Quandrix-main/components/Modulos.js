import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, List, useTheme, TextInput, Text, Title, Surface } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors} from '../utils/myStyles'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";

export default function Modulo({ navigation }) {

  const handleBackToMain = () => {
    navigation.goBack(); 
  };

  const handleDificuldade = (module) => {

    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid )).then( (student) => {
      if('questoes' in student.val()){
        if(module in student.val().questoes){
          navigation.navigate('Dificuldade', {
            module: module
          }); 
        }
        else{
          navigation.navigate('TesteInicial', {
            module: module
          }); 
        }
      }
      else{
        navigation.navigate('TesteInicial', {
          module: module
        }); 
      }
    }).catch((error) => {
      console.log(error);
    })
  };

  return (
    <View style={styles.container}>
      {/* Background */}
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <Surface style={styles.modules} elevation={0}>
        <Text style={myStyles.header} variant="displayLarge"> Módulos </Text>
          <View style={styles.buttons}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleDificuldade('algebra')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              icon={({ size, color }) => (
                  <MaterialIcons name="add" size={size} color={color} />
              )}
            >
              Álgebra
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleDificuldade('geometria')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              icon={({ size, color }) => (
                  <MaterialIcons name="architecture" size={size} color={color} />
              )}
            >
              Geometria
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={() => handleDificuldade('funcoes')}
              style={styles.button}
              labelStyle={{fontFamily: 'RobotoMono'}}
              icon={({ size, color }) => (
                  <MaterialIcons name="trending-up" size={size} color={color} />
              )}
            >
              Funções
          </Button>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleBackToMain}
              style={styles.button}
              icon={({ size, color }) => (
                  <MaterialIcons name="undo" size={size} color={color} />
              )}
            >
              Voltar
          </Button>   
          </View>
        </Surface>
        </LinearGradient>
        </View>
  );
}

const styles = StyleSheet.create({
  modules: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '80%',
    paddingVertical:30,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    alignContent: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttons: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    width: '80%',
  },
  button: {
    margin: 4,
    fontFamily: 'RobotoMono',
    borderColor: 'black',
    borderWidth: 1                                  
  },
});
