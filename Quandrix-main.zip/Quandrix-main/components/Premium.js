import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, List, useTheme, TextInput, Text, Surface, Snackbar, Provider } from 'react-native-paper';
import {myStyles, gradientColors, snackbarColors} from '../utils/myStyles'
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils';

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";

export default function CoinsScreen({ navigation }) {

  const [coins, setCoins] = useState(0);
  const premiumCost = 50; 
  const [visible, setVisible] = useState(false);
  const [successfulBuy, setSuccessfulBuy] = useState(true);
  const [isPremium, setIsPremium] = useState(false);

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid + '/moedas')).then( (snapshot) => {
      if(snapshot.exists()){
        setCoins(snapshot.val());
      }
      else {
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })

    get(child(dbRef, 'estudantes/' + uid + '/vip')).then( (snapshot) => {
      if(snapshot.exists()){
        setIsPremium(snapshot.val());
      }
      else {
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
  }, [auth.currentUser, dbRef]);

  const handleBuyPremium = () => {
    if (coins >= premiumCost && !isPremium) {
      if(auth.currentUser === null){
        console.error("Error: null user!");
        return;
      }
      console.log("teste");
      const uid = auth.currentUser.uid;
      const updates = {};
      updates['/estudantes/' + uid + '/vip'] = true;
      updates['/estudantes/' + uid + '/moedas'] = coins - premiumCost;
  
      update(dbRef, updates).then( (update) => {
        setCoins(coins - premiumCost);
        setIsPremium(true);
        setSuccessfulBuy(true);
      }).catch((error) => {
        setSuccessfulBuy(false);
      })
      setVisible(true);
    } else {
      setSuccessfulBuy(false);
      setVisible(true);
    }
  };

  const handleBack = () => {
    navigation.goBack();
  };

  return (
    <Provider theme={ successfulBuy ? colorThemes['green']['dark'] : colorThemes['red']['dark'] }>
      <View style={styles.container}>
        <LinearGradient
          colors={gradientColors}
          style={styles.background}
        >
          <Surface style={styles.content} elevation={0}>
            <Text style={[myStyles.header, { textAlign: 'center' , marginBottom: '8%'}]}>Usuário Premium</Text>
            <Text style={[myStyles.labels, { textAlign: 'center', fontSize: 22 }]}>Você tem: {coins} moedas</Text>
            {isPremium ? 
              (<Text style={[myStyles.labels, { textAlign: 'center', fontSize: 22 }]}>Você já é Premium!</Text>) : 
              (<Text style={[myStyles.labels, { textAlign: 'center', fontSize: 22 }]}>Preço: {premiumCost} moedas</Text>)
            }
            <View style={styles.buttonContainer}>
              <Button style={
                  [styles.buyButton, { backgroundColor: !isPremium ? 'rgba(255,215,0, 0.9)' : 'rgba(160,160,160, 0.9)'}]
                } 
                onPress={handleBuyPremium} disabled={isPremium}
                icon={({ size, color }) => (
                <MaterialIcons name="done-all"  size={size} color={'black'} />
              )}>
                <Text style={styles.buybuttonText}>Comprar Premium</Text>
              </Button>
              <Button style={styles.backButton} onPress={handleBack}
                icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'white'} />
              )}>
                <Text style={styles.buttonText}>Voltar</Text>
              </Button>
            </View>
          </Surface>
        </LinearGradient>
        <Snackbar
          visible={visible}
          onDismiss={() => setVisible(false)}
          action={{
            label: 'Fechar',
            onPress: () => {
              setVisible(false)
            },
          }}
          duration={Snackbar.DURATION_MEDIUM}
          style={{ backgroundColor: successfulBuy ? snackbarColors['success'] : snackbarColors['error'] }}
        >
          {successfulBuy ? 'Premium comprado com sucesso!' : 
          isPremium ? 'Erro ao efetuar compra, usuário já é Premium!' : 
          'Erro ao efetuar compra, moedas insuficientes!'}
        </Snackbar>
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '80%',
    paddingVertical:30,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    alignContent: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  buttonContainer: {
    width: '100%',
    paddingHorizontal: 16,
    marginTop: 20,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 24,
  },
  buyButton: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
  },
  buybuttonText: {
    fontSize: 16,
    color: 'black',
    textAlign: 'center',
  },
});
