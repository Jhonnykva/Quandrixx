import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {Text, Button, Avatar, FAB, Provider, TextInput, Surface} from 'react-native-paper'
import {myStyles, gradientColors} from '../utils/myStyles'
import { colorThemes } from '../utils';
import DialogWithRadioButtons from './Dialog/DialogWithRadioButtons'
import { MaterialIcons } from '@expo/vector-icons';
import { Camera, CameraType } from 'expo-camera';
import * as Location from 'expo-location';
import axios from 'axios';

import { countries, countryFlags, countryCodes } from '../utils/countries';

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { getStorage, uploadBytes, ref as storageRef, getDownloadURL } from 'firebase/storage'; 

import { checkOffensiveStatus } from '../utils/offensive';

export default function ProfileScreen({ navigation }) {

  const [visible, setVisible] = useState(false);
  const [username, setUsername] = useState(''); 
  const [country, setCountry] = useState('');
  const [countryFlag, setCountryFlag] = useState(null);
  const [renaming, setRenaming] = useState(false);

  const [offensiveValue, setOffensiveValue] = useState(0);
  const [offensiveStatus, setOffensiveStatus] = useState(null);

  const [type, setType] = useState(CameraType.back);
  const [permission, requestPermission] = Camera.useCameraPermissions();
  const [camera, setCamera] = useState(null);
  const [hasPermission, setHasPermission] = useState(null); 
  const [photo, setPhoto] = useState(null);
  const [takingPicture, setTakingPicture] = useState(false);

  useEffect(() => {
    (async () => {
    const { status } = await Camera.requestCameraPermissionsAsync();
    setHasPermission(status === "granted");
        })();
  }, []);

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, 'estudantes/' + uid )).then( (snapshot) => {
      if(snapshot.exists()){
        if(snapshot.val().nomeDeUsuario){
          setUsername(snapshot.val().nomeDeUsuario);
        }
        if(snapshot.val().pais !== ""){
          setCountry(snapshot.val().pais);
          setCountryFlag(countryFlags[snapshot.val().pais])
        }
      }
      else {
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
    const stRef = storageRef(getStorage(app), 'usuarios/' + uid + '/Foto.jpg');
    getDownloadURL(stRef).then((url) => {
      setPhoto(url);
    }).catch((error) => {
      console.error(error);
    })
  }, [auth.currentUser, dbRef]);

  useEffect(() => {
    const fetchOffensive = async () => {
      const {value, status} = await checkOffensiveStatus();
      if(status === 'Restorable'){
        setOffensiveValue(0);
      }
      else {
        setOffensiveValue(value);
      }
      setOffensiveStatus(status);
      console.log(status);
    };
    fetchOffensive();
  }, []);

  const handleShowProgress = () => {
    navigation.navigate('Progresso');
  };

  const handlePremium = () => {
    navigation.navigate('Premium');
  }

  const handleRename = () => {
    setRenaming(!renaming)
  }

  const handleSave = () => {
    if(auth.currentUser === null){
      console.error("Error: null user!");
      return;
    }
    
    const uid = auth.currentUser.uid;
    const updates = {};
    updates['/estudantes/' + uid + '/nomeDeUsuario'] = username;
    updates['/estudantes/' + uid + '/pais'] = country;

    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      setSuccessfulRegister(false);
      setSnackbarMessage("Erro ao atualizar o banco de dados!");
    })

    const uploadPhoto = async () => {
      if(photo){
        const stRef = storageRef(getStorage(app), 'usuarios/' + uid + '/Foto.jpg');
        const data = await fetch(photo);
        const blob = await data.blob();
        uploadBytes(stRef, blob).then((snapshot) => { 
        }).catch((error) => {
          console.error(error);
        })
      }
    }
    uploadPhoto();

  }

  const handleGoBack = () => {
    navigation.goBack();
  };

  const registerCountry = (country, countryFlag) => {
    setCountry(country);
    setCountryFlag(countryFlag);
    setVisible(!visible);
  }

  const takePicture = async () => {
    if (camera) {
      const photo = await camera.takePictureAsync();
      setPhoto(photo.uri);
      setTakingPicture(false);
    }
  };

  const toggleCameraType = () => {
    setType(current => (current === CameraType.back ? CameraType.front : CameraType.back));
  }

  const getLocation = async() => {
    try{
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.error('Permissão para acessar a localização negada');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      console.log('Localização atual:', location);
      const latitude = location.coords.latitude;
      const longitude = location.coords.longitude;
      axios.get(`http://api.geonames.org/findNearbyJSON?lat=${latitude}&lng=${longitude}&username=ge85222`)
      .then(response => {
        const countryCode = response.data.geonames[0].countryCode;
        const countryName = countryCodes[countryCode];
        setCountry(countryName);
        setCountryFlag(countryFlags[countryName]);
      })
      .catch(error => {
        console.error('Error fetching country: ', error);
      });
    }
    catch(error){
      let status = Location.hasServicesEnabledAsync();
      if(!status){
        alert('Enable Location Service');
      }
    }
  }

  return (
    <Provider theme={colorThemes['green']['light']}>
      {!takingPicture && <View style={styles.container}>
        <LinearGradient
          colors={gradientColors}
          style={styles.background}
        >
          <View style={styles.content} elevated={0}>
          <Text style={myStyles.header} variant="displayLarge">Perfil de</Text>
          <Text style={myStyles.header} variant="displayLarge">Usuário</Text>
            <View style={styles.userContainer}>
              <Avatar.Image
                style={styles.avatar}
                source={photo ? {uri: photo} : require('../assets/avatar.png')}
                size={80}
              />
              <View style={styles.row}>
                {!renaming && <Text style={[myStyles.labels, {fontWeight: 'bold'}]}> Nome: </Text>}
                {!renaming ? (<Text style={myStyles.labels}>
                  {username === '' ? String.fromCodePoint(0x2753) : username}
                </Text>) :
                (<TextInput
                  mode="outlined"
                  style={styles.usernameInput}
                  dense
                  value={username}
                  onChangeText={setUsername}
                />) }
                <FAB 
                  icon={!renaming ? ({ size, color }) => (
                    <MaterialIcons name="edit" size={size-10} color={color} />
                  ) : ({ size, color }) => (
                    <MaterialIcons name="check" size={size-10} color={color} />
                  )}
                  style={styles.fab}
                  onPress={handleRename}
                  visible={true}
                  size={'small'}
                  color={'black'}
                />
              </View>
              <View style={styles.row}>
                <Text style={[myStyles.labels, {fontWeight: 'bold'}]}> 
                  País: {' '}  
                </Text>
                <Text style={myStyles.labels}> 
                  {country === '' ? String.fromCodePoint(0x2753) : country}
                </Text>
                {countryFlag && <Image source={countryFlag} style={styles.image}/>}
              </View>
              <View style={styles.row}>
                
                <FAB
                    icon={({ size, color }) => (
                      <MaterialIcons name="edit" size={size-10} color={color} />
                    )}
                    style={styles.fab}
                    onPress={() => {setVisible(!visible);}}
                    visible={true}
                    size={'small'}
                    color={'black'}
                  />
                  <FAB 
                    icon={({ size, color }) => (
                      <MaterialIcons name="language"  size={size-10} color={color} />
                    )}
                    style={styles.fab}
                    onPress={getLocation}
                    visible={true}
                    size={'small'}
                    color={'black'}
                  />
              </View>
            </View>
            <Text style={styles.daysPlayedText}>  Dias de Ofensiva: {offensiveValue} {String.fromCodePoint(0x1F525)} </Text>
            <Button style={styles.button} onPress={handlePremium} 
              icon={({ size, color }) => (
                <MaterialIcons name="military-tech"  size={size} color={'white'} />
              )} >
              <Text style={styles.buttonText} >Comprar Premium</Text>
            </Button>
            <Button style={styles.button} onPress={handleShowProgress}
              icon={({ size, color }) => (
                <MaterialIcons name="insights"  size={size} color={'white'} />
              )} >
              <Text style={styles.buttonText}>Mostrar Progresso</Text>
            </Button>
            <Button style={styles.button} onPress={() => {setTakingPicture(true)}}
              icon={({ size, color }) => (
                <MaterialIcons name="photo-camera"  size={size} color={'white'} />
              )} >
              <Text style={styles.buttonText}>Trocar foto de usuário</Text>
            </Button>
            <Button style={styles.button} onPress={handleSave}
              icon={({ size, color }) => (
                <MaterialIcons name="save"  size={size} color={'white'} />
              )}>
              <Text style={styles.buttonText}>Salvar alterações</Text>
            </Button>
            <Button style={styles.button} onPress={handleGoBack}
              icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'white'} />
              )}>
              <Text style={styles.buttonText}>Voltar</Text>
            </Button>
            <DialogWithRadioButtons
              visible={visible}
              close={() => {setVisible(!visible);}}
              registerAnswer={registerCountry}
            />
          </View>
        </LinearGradient>
      </View>}
      {takingPicture && <>
      <View style={styles.simpleContainer}></View>
      <Camera style={{flex: 0.68}} type={type} ref={(ref) => setCamera(ref)}>
      </Camera>
      <View style={styles.buttonContainer}>
          <Button style={styles.cameraButton} onPress={toggleCameraType} 
              icon={({ size, color }) => (
                <MaterialIcons name="flip-camera-ios"  size={size} color={'#999900'} />
              )} >
              <Text style={styles.camerabuttonText} >Virar Câmera</Text>
          </Button>
          <Button style={styles.cameraButton} onPress={takePicture} 
              icon={({ size, color }) => (
                <MaterialIcons name="add-a-photo"  size={size} color={'#999900'} />
              )} >
              <Text style={styles.camerabuttonText} >Tirar Foto</Text>
          </Button>
          <Button style={styles.cameraButton} onPress={() => {setTakingPicture(false)}} 
              icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'#999900'} />
              )} >
              <Text style={styles.camerabuttonText} >Voltar</Text>
          </Button>
        </View>
        </>
      }
    </Provider>
    
  );
}

const styles = StyleSheet.create({
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '90%',
    paddingVertical:30,
    paddingBottom: 15,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    alignContent: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userContainer: {
    alignItems: 'center',
  },
  avatar: {
    marginTop: 20,
    marginBottom: 20,
  },
  usernameInput: {
    fontSize: 14,
    borderColor: 'white',
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
    color: 'blue',
    marginRight: 5,
    marginLeft: 20,
    width:'66%',
  },
  daysPlayedText: {
    fontSize: 18,
    marginBottom: 30,
    marginTop: 10,
    color: 'orange',
    fontWeight: 'bold',
    fontFamily: 'RobotoMono',
  },
  button: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 8,
    paddingVertical: 0,
    width:'75%',
    alignItems: 'center',
    marginBottom: 10,
    borderColor: 'black',
    borderWidth: 0.3  
  },
  buttonText: {
    fontSize: 16,
    color: 'white',
  },
  fab: {
    margin: 8,
    marginTop: 0,
    marginBottom: 0,
    width: 30,
    height: 30,
  },
  row: {
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 40,
    height: 24,
    marginLeft: '3%',
  },
  camera: {
    flex: 1,
  },
  cameraButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 8,
    paddingVertical: 0,
    width:'75%',
    alignItems: 'center',
    marginBottom: 10,
    borderColor: '#999900',
    borderWidth: 0.3,
    alignSelf: 'center'
  },
  simpleContainer: {
    flex: 0.12,
    backgroundColor: 'black'
  },
  buttonContainer: {
    flex: 0.20, // Make the container take the full height
    justifyContent: 'flex-end', // Align items at the bottom
    backgroundColor: 'black',
  },
  camerabuttonText: {
    fontSize: 20,
    color: 'black',
  },
});



