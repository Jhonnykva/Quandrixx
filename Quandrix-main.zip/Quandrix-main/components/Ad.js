import React, { useState } from 'react';
import { View, StyleSheet, ImageBackground, TouchableOpacity, Linking } from 'react-native';
import CountDownButton from '../utils/CountDownButton';

export default function Ad({ navigation }) {

  const handleClose = () => {
    navigation.goBack();
  };

  const handlePressAd = () => {
    const url = 'https://cloud.news.mcdonalds.com.br/meu-mequi?utm_source=adwords&utm_medium=cpc&utm_campaign=galeria_branding_awareness_full-price_jad-institucional_clicklink_meu-mequi&utm_content=galeria_branding_awareness_full-price_jad-institucional_clicklink_meu-mequi_reach_adwords_cpc_open_all_all_search_in-search_in-search_loyalty_null&gad_source=1&gclid=CjwKCAiA04arBhAkEiwAuNOsImPibDm0U9j7mSKS0pPFQsn-21XLSS5tOZyZ1xk30Ei4g-ktqHL-mRoCPN4QAvD_BwE'; // Replace with your website URL
    Linking.openURL(url);
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handlePressAd} activeOpacity={0.8} style={{flex: 1}}>
        <ImageBackground
          style={styles.ad}
          source={require('../assets/ad.png')}
          resizeMode='cover'
        >
          <View style={styles.overlay}>
            <CountDownButton  onClose={handleClose}/>
          </View>
        </ImageBackground>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  ad: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    position: 'absolute',
    top: 0,
    right: 0,
    padding: 16,
  },
});
