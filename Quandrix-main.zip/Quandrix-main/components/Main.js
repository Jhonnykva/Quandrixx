import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {Button, Text, IconButton, Provider, Surface} from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors} from '../utils/myStyles'
import { colorThemes } from '../utils';

export default function Main({ navigation }) {

  const formatDateToYYMMDD = (date) => {
    const year = date.getFullYear();
    console.log(year);
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); 
    const day = date.getDate().toString().padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    return formattedDate;
  }

  const handlePageSwitch = (page) => {
    navigation.navigate(page);
  }

  const handleDailyChallenge = () => {
    navigation.navigate('Desafio', {
      day: formatDateToYYMMDD(new Date()),
    });
  }

  const handleRedoWrongQuestions = () => {

  }

  return (
    <Provider theme={colorThemes['cyan']['light']}>
      <View style={styles.container}>
        <LinearGradient
          colors={gradientColors}
          style={styles.background}
        >
          <Surface style={styles.content} elevation={0}>
            <Text style={myStyles.header} variant="displayLarge">Quandrix</Text>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#00A2E6"}
                onPress={() => handlePageSwitch('Modulos')}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon={({ size, color }) => (
                  <MaterialIcons name="school" size={size} color={color} />
                )}
                contentStyle={{ flexDirection: 'row' }}
              >
                Selecionar Módulo
              </Button>
            </View>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#EEB770"}
                onPress={() => handlePageSwitch('Loja')}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon={({ size, color }) => (
                  <MaterialIcons name="store" size={size} color={color} />
                )}
                contentStyle={{ flexDirection: 'row' }}
              >
                Loja
              </Button>
            </View>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#70EE8D"}
                onPress={() => handlePageSwitch('Inventario')}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon={({ size, color }) => (
                  <MaterialIcons name="backpack" size={size} color={color} />
                )}
                contentStyle={{ flexDirection: 'row' }}
              >
                Inventário
              </Button>
            </View>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#EEE970"}
                onPress={() => handlePageSwitch('Conquistas')}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon="trophy"
                contentStyle={{ flexDirection: 'row' }}
              >
                Conquistas
              </Button>
            </View>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#C470EE"}
                onPress={() => handleDailyChallenge()}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon={({ size, color }) => (
                  <MaterialIcons name="event" size={size} color={color} />
                )}
                contentStyle={{ flexDirection: 'row' }}
              >
                Desafio diário
              </Button>
            </View>
            <View style={styles.button}>
              <Button
                style={{borderColor: 'black', borderWidth: 1}}
                mode="contained-tonal"
                buttonColor={"#EE7079"}
                onPress={() => handlePageSwitch('Erradas')}
                labelStyle={{fontFamily: 'RobotoMono'}}
                icon={({ size, color }) => (
                  <MaterialIcons name="dangerous" size={size} color={color} />
                )}
                contentStyle={{ flexDirection: 'row' }}
              >
                Refazer Errados
              </Button>
            </View>
            <View style={styles.circularButtonContainer}>
              <IconButton icon={({ size, color }) => (
                            <MaterialIcons name="person" size={size} color={color} />
                          )} 
                mode="contained" selected size={24} onPress={() => handlePageSwitch('Perfil')} 
                style={{borderColor: 'black', borderWidth: 1}}
              />
              <IconButton icon={({ size, color }) => (
                            <MaterialIcons name="notes" size={size} color={color} />
                          )} 
                mode="contained" selected size={24} onPress={() => handlePageSwitch('Notas')} 
                style={{borderColor: 'black', borderWidth: 1}}
              />
            </View>
          </Surface> 
        </LinearGradient>
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '80%',
    paddingTop:30,
    paddingBottom:20,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center'
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    width: '80%',
    paddingVertical:4,
    marginVertical: 4,
    justifyContent: 'center',
  },
  circularButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 0,
    marginTop: 10,
  },
});
