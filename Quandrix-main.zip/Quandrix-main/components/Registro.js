import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, List, useTheme, TextInput, Text, Surface, Snackbar, Provider, HelperText } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors, snackbarColors} from '../utils/myStyles'
import { colorThemes } from '../utils';
import validator from 'validator';

import {app, authErrorCodes, auth, db, dbRef} from '../firebase/config'
import {createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import {update} from "firebase/database";

export default function Registro({ navigation }) {

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSecureEntry, setpasswordSecureEntry] = useState(true);
  const [confirmPasswordSecureEntry, setConfirmPasswordSecureEntry] = useState(true);
  const [successfulRegister, setSuccessfulRegister] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('')

  const _isEmailValid = (email) => {
    return validator.isEmail(email) || email === '' ;
  };

  const handleRegister = () => {
    if (password === confirmPassword) {
      createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          const user = userCredential.user;
          updateProfile(user, {
            displayName: username
          }).then(() => {
            setSnackbarMessage('Usuário registrado com sucesso');
            setSuccessfulRegister(true);
          }).catch((error) => {
            setSnackbarMessage(authErrorCodes[error.code]);
            setSuccessfulRegister(false);
          });
          const newItens = {
            desafio: 0,
            moedas: 0,
            ofensiva: 0
          };
          const conquistas = {
            0 : false,
            1 : false,
            2 : false
          };
          const updates = {};
          updates['/estudantes/' + user.uid + '/itens'] = newItens;
          updates['/estudantes/' + user.uid + '/moedas'] = 0;
          updates['/estudantes/' + user.uid + '/nomeDeUsuario'] = username;
          updates['/estudantes/' + user.uid + '/pais'] = '';
          updates['/estudantes/' + user.uid + '/questoesErradas'] = [];
          updates['/estudantes/' + user.uid + '/tempoDeOfensiva'] = 0;
          updates['/estudantes/' + user.uid + '/vip'] = false;
          updates['/estudantes/' + user.uid + '/conquistas'] = conquistas;

          update(dbRef, updates).then( (update) => {
          }).catch((error) => {
            setSuccessfulRegister(false);
            setSnackbarMessage("Erro ao atualizar o banco de dados!");
          })
        })
        .catch((error) => {
          setSnackbarMessage(authErrorCodes[error.code]);
          setSuccessfulRegister(false);
        });
      } else {
        setSnackbarMessage("As senhas não conferem");
        setSuccessfulRegister(false);
      }
      setSnackbarVisible(true);
  };

  const handleBackToLogin = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <Surface style={styles.registrationForm} elevation={0}>
          <Text style={[myStyles.header, {marginBottom: '7%'}]}>Registrar</Text>
          <Text style={myStyles.labels}>Nome de Usuário:</Text>
          <TextInput
            style={styles.input}
            label="Digite seu nome de usuário"
            value={username}
            underlineColor = "#000000"
            activeUnderlineColor = "#000000"
            onChangeText={(text) => setUsername(text)}
          />
          <Text style={myStyles.labels}>E-mail:</Text>
          <TextInput
            style={[styles.input, { marginBottom: 0 }]}
            label="Digite seu e-mail"
            value={email}
            underlineColor = "#000000"
            activeUnderlineColor = "#000000"
            onChangeText={(text) => setEmail(text)}
            keyboardType="email-address"
            error={!_isEmailValid(email)}
          />
          <View style={{ padding: 0, margin: 0 }}>
            <HelperText
              type="error"
              visible={!_isEmailValid(email)}
            >
              <Text>Erro: E-mail Inválido</Text>
            </HelperText>
          </View>
          <Text style={myStyles.labels}>Senha:</Text>
          <TextInput
            style={styles.input}
            underlineColor = "#000000"
            activeUnderlineColor = "#000000"
            label="Digite sua senha"
            value={password}
            onChangeText={(text) => setPassword(text)}
            secureTextEntry={passwordSecureEntry}
            right={
              <TextInput.Icon
                icon={passwordSecureEntry ? 'eye' : 'eye-off'}
                onPress={() =>
                setpasswordSecureEntry(!passwordSecureEntry)
                }
                forceTextInputFocus={false}
              />
            }
          />
          <Text style={myStyles.labels}>Repita a Senha:</Text>
          <TextInput
            style={styles.input}
            underlineColor = "#000000"
            activeUnderlineColor = "#000000"
            label="Repita sua senha"
            value={confirmPassword}
            onChangeText={(text) => setConfirmPassword(text)}
            secureTextEntry={confirmPasswordSecureEntry}
            right={
              <TextInput.Icon
                icon={confirmPasswordSecureEntry ? 'eye' : 'eye-off'}
                onPress={() =>
                setConfirmPasswordSecureEntry(!confirmPasswordSecureEntry)
                }
                forceTextInputFocus={false}
              />
            }
          />
          <View style={styles.buttons}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleBackToLogin}
              style={styles.button}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
            )}
            >
              <Text>Voltar</Text>
            </Button>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleRegister}
              style={styles.button}
              icon={({ size, color }) => (
                <MaterialIcons name="how-to-reg" size={size} color={color} />
            )}
            >
             <Text>Registrar</Text> 
            </Button>
          </View>
        </Surface>
      </LinearGradient>
      <Snackbar
          visible={snackbarVisible}
          onDismiss={() => setSnackbarVisible(false)}
          action={{
            label: 'Fechar',
            onPress: () => {
              setSnackbarVisible(false)
            },
          }}
          duration={Snackbar.DURATION_MEDIUM}
          style={{ backgroundColor: successfulRegister ? snackbarColors['success'] : snackbarColors['error'] }}
          theme={successfulRegister ? colorThemes['green']['dark'] : colorThemes['red']['dark']}
        >
          <Text>{snackbarMessage}</Text>
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  registrationForm: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '80%',
    paddingTop:30,
    paddingBottom: 10,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    width: '80%',
    height: 60,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
    fontSize: 15
  },
  button: {
    margin: 4,
    backgorund: 'blue',
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
  },
});
