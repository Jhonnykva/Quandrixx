import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, ScrollView, TouchableOpacity, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors} from '../utils/myStyles'
import {Surface, Button} from 'react-native-paper'

import {app} from '../firebase/config'
import { getAuth } from "firebase/auth";
import { getDatabase, ref, get, child} from "firebase/database";

export default function PatchNotesScreen({ navigation }) {

  const auth = getAuth(app);
  const dbRef = ref(getDatabase(app));

  const [patchNotes, setPatchNotes] = useState({});

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }
    
    const uid = auth.currentUser.uid;
      
    get(child(dbRef, 'notasDeAtualizacao')).then( (snapshot) => {
      if(snapshot.exists()){
        console.log(snapshot.val());
        setPatchNotes(snapshot.val());
      }
      else {
        setPatchNotes({});
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
  }, [ auth.currentUser, dbRef]);

  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <View style={styles.content}>
        <Text style={[myStyles.header,{alignSelf: 'center', marginBottom: '5%'}]} variant="displayLarge">Notas de Atualização</Text>
          <Button style={styles.goBackButton} onPress={handleGoBack}
          icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'white'} />
              )}>
            <Text style={styles.goBackText}>Voltar</Text>
          </Button>
          <ScrollView style={styles.scrollView}>
            {Object.keys(patchNotes).map((key, index) => (
              <View key={index} style={[styles.noteContainer]}>
                <Text style={styles.noteText}>{patchNotes[key]["timestamp"]}</Text>
                <Text style={styles.noteText}>{patchNotes[key]["descrição"]}</Text>
              </View>
            ))}
          </ScrollView>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  scrollView: {
    flex: 1,
    marginBottom: 20,
  },
  noteContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  noteText: {
    fontSize: 16,
    color: 'white',
  },
  goBackButton: {
    marginBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 4,
    alignItems: 'center',
  },
  goBackText: {
    fontSize: 16,
    color: 'white',
  },
});
