import {useState, useEffect} from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Button, List, useTheme, TextInput, Text, ActivityIndicator,Title, Divider, Provider } from 'react-native-paper';
import {myStyles, gradientColors} from '../utils/myStyles'
import { colorThemes } from '../utils';

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import Modulo from './Modulos';



export default function Fundamentacao({route,  navigation }) {

  const [expanded, setExpanded] = useState(false);
  const [dynamicAccordions, setDynamicAccordions] = useState([]);
  const {module, level} = route.params;


  const _handlePress = () => {
    setExpanded(!expanded);
  };

  const handleGoBack = () => {
    navigation.goBack();

  };

  const handleGoFundamentation = (module, tema, conteudo) => {
    navigation.navigate('ContentFundamentation',{
      module: module,
      tema: tema,
      content:conteudo,
    });

  };

  useEffect(() => {
    get(child(dbRef, 'fundamentacao/' + module))
      .then((snapshot) => {
        if (snapshot.exists()) {
          console.log(snapshot.val());
          const jsonReturn = snapshot.val();

          const accordions = Object.keys(jsonReturn).map((tema, index) => (
            
            <List.Accordion
              key={index}
              left={(props) => <List.Icon {...props} icon="folder" />}
              title={tema}  
              titleStyle={styles.accordionTitle}
              theme={{ colors: { background: 'transparent' } }}
            >
              {Object.keys(jsonReturn[tema]).map((conteudo, conteudoIndex) => (
                <TouchableOpacity
                key={conteudoIndex}
                onPress={() => handleGoFundamentation(module, tema, conteudo)}
                style={styles.itemContainer}
              >
                <List.Item
                  title={conteudo}
                  titleStyle={styles.itemTitle}
                  left={(props) => <List.Icon {...props} icon="thumb-up" />}
                />
              </TouchableOpacity>
              ))}
            </List.Accordion>
          ));

          setDynamicAccordions(accordions);

          
        } else {
          console.log("No data available");
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  

  return (
    <Provider theme={colorThemes['cyan']['dark']}>
      <View style={styles.container}>
        <LinearGradient
          colors={gradientColors}
          style={styles.background}
        >
          <List.Section title={module} titleStyle={myStyles.title}>
            <TouchableOpacity style={styles.goBackButton} onPress={handleGoBack}>
              <Text style={styles.goBackText}>Voltar</Text>
            </TouchableOpacity>
            {dynamicAccordions}
          </List.Section>
        </LinearGradient>
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  accordionTitle: {
    color: 'white',
    fontFamily: 'RobotoMono',
  },
  itemTitle: {
    color: 'white',
  },
    goBackButton: {
    marginBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 20,
  },
  goBackText: {
    fontSize: 16,
    color: 'white',
  },
});
