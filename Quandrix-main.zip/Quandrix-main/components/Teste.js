import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradientColors} from '../utils/myStyles'
import {Button, Text, Provider, Surface, ActivityIndicator} from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils/index'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage';

import { QuestionContainer, OptionAnswerContainer, TextAnswerContainer, RightAnswerFeedback, WrongAnswerFeedback } from '../utils/QuestionComponents';

export default function QuestionScreen({ navigation, route }) {
  const { module } = route.params;
  const [question, setQuestion] = useState(null);
  const [questions, setQuestions] = useState(null);
  const options = ['A', 'B', 'C', 'D', 'E'];
  const [correctAnswer, setCorrectAnswer] = useState(null);
  const [noQuestions, setNoQuestions] = useState(false);
  const [questionType, setQuestionType] = useState("fechada");

  const [userAnswer, setUserAnswer] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [rightAnswer, setRightAnswer] = useState(null);

  const [questionIndex, setQuestionIndex] = useState(0);
  const [questionResults, setQuestionResults] = useState([]);
  const questionLevels = ['facil', 'facil', 'medio', 'medio', 'dificil', 'dificil'];

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function randomizeTwoElements(list) {
    const index1 = getRandomInt(0, list.length - 1);
  
    let index2;
    do {
      index2 = getRandomInt(0, list.length - 1);
    } while (index2 === index1);
    
    list = [list[index1], list[index2]];
  
    return list;
  }

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    get(child(dbRef, "questoes/" + module)).then( (questions) => {
      if(questions.exists()){
        const easyQuestions = randomizeTwoElements(questions.val().facil);
        const mediumQuestions = randomizeTwoElements(questions.val().medio);
        const hardQuestions = randomizeTwoElements(questions.val().dificil);
        const testQuestions = easyQuestions.concat(mediumQuestions, hardQuestions);
        setQuestions(testQuestions);
        console.log(testQuestions);
        const stRef = storageRef(
          getStorage(app), "questoes/" + module + '/' + questionLevels[questionIndex] + '/' + testQuestions[questionIndex].id + '.PNG'
        );
        getDownloadURL(stRef).then((url) => {
          setQuestion(url);
          setCorrectAnswer(testQuestions[questionIndex].resposta);
          setQuestionType(testQuestions[questionIndex].tipo);
        }).catch((error) => {
          console.log("Error: downloading image!");
          console.error(error.code);
        })
      }
      else {
        console.log("Error: snapshot doesn't exists!");
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })        

  }, [auth.currentUser, dbRef]);


  const handleConfirm = () => {

    if(userAnswer === correctAnswer){
      setRightAnswer(true);
      setQuestionResults([...questionResults, true]);
    }
    else{
      setRightAnswer(false);
      setQuestionResults([...questionResults, false]);
    }

    setConfirmed(true);
    setQuestionIndex(questionIndex + 1);
  };

  const handleGoBack = () => {
    navigation.goBack();
  }

  const handleContinue = () => {

    if(questionIndex === 6){
      setNoQuestions(true);
      return;
    }

    const stRef = storageRef(
      getStorage(app), "questoes/" + module + '/' + questionLevels[questionIndex] + '/' + questions[questionIndex].id + '.PNG'
    );
    getDownloadURL(stRef).then((url) => {
      setQuestion(url);
      setCorrectAnswer(questions[questionIndex].resposta);
      setQuestionType(questions[questionIndex].tipo);
    }).catch((error) => {
      console.log("Error: downloading image!");
      console.error(error.code);
    })
    setConfirmed(false); 
    setRightAnswer(null);
    setUserAnswer(null);  
  }

  const handleFinish = () => {
    if(auth.currentUser === null){
      console.error("Error: null user!");
      return;
    }
    
    const uid = auth.currentUser.uid;
    const updates = {};
    let wrongQuestions = 0;
    console.log(questionResults);
    for(let i = 0 ; i< 6 ; i++){
      if(!questionResults[i]){
        updates['/estudantes/' + uid + '/questoesErradas/' + wrongQuestions ] = 
          'questoes/' + module + '/' + questionLevels[i] + '@' + (parseInt(questions[i].id ));
        wrongQuestions++;
      }
      updates['/estudantes/' + uid + '/questoes/' + module + '/' + questionLevels[i] + '/' + (i%2) ] = questions[i].id;
    }

    if(!questionResults[0] || !questionResults[1]){
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/facil'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/medio'] = false;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/dificil'] = false;
    }
    else if(!questionResults[2] || !questionResults[3]){
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/facil'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/medio'] = false;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/dificil'] = false;
    }
    else if(!questionResults[4] || !questionResults[5]){
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/facil'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/medio'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/dificil'] = false;
    }
    else{
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/facil'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/medio'] = true;
      updates['/estudantes/' + uid + '/dificuldades/' + module + '/dificil'] = true;
    }

    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      console.log(error.code);
      setSuccessfulRegister(false);
      setSnackbarMessage("Erro ao atualizar o banco de dados!");
    });
    
    navigation.navigate('Dificuldade', {
      module: module
    }); 

  }

  return (
    <Provider theme={
    rightAnswer === null
      ? colorThemes['blue']['light']
      : rightAnswer === true
      ? colorThemes['green']['light']
      : colorThemes['red']['light']
    }>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        {(!noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <QuestionContainer 
            question={question} 
            confirmed={confirmed} 
            rightAnswer={rightAnswer} 
          />
          {questionType === "fechada" &&
            <OptionAnswerContainer 
              confirmed={confirmed} 
              options={options} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {questionType === "aberta" && 
            <TextAnswerContainer 
              confirmed={confirmed} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {rightAnswer === true && 
            <RightAnswerFeedback 
              doubleRewardActive={false}
              baseCoinReward={0}
              progress={true}  
            />
          }
          {rightAnswer === false && 
            <WrongAnswerFeedback
              auxiliarText={"Tente novamente depois!"}
            />
          }
          {(userAnswer!=null && confirmed === false) &&
          <Button
              mode="contained-tonal"
              buttonColor={"#66FF66"}
              onPress={handleConfirm}
              style={styles.confirmButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="done" size={size} color={color} />
              )}
          >
            Confirmar
          </Button>  }
          {confirmed === true && <View style={styles.row}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleContinue}
              style={styles.continueButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="play-arrow" size={size} color={color} />
              )}
          >
            Continuar
          </Button>  
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={styles.goBackButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
          </View>
          }
        </Surface> }
        {(noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <Text style={styles.noQuestionsText}>
            Teste Inicial finalizado com sucesso! 
          </Text>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleFinish}
              style={[styles.goBackButton, {alignSelf: 'center'}]}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="flag" size={size} color={color} />
              )}
          >
            Finalizar
          </Button>
        </Surface>}
        {(!question) && <Surface style={styles.container} elevation={0}>
          <ActivityIndicator animating={true} size='large'/>
        </Surface>}
      </LinearGradient>
    </Provider>
  );
}

const styles = StyleSheet.create({
 container: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '85%',
    height: '85%',
    paddingTop:20,
    paddingBottom:20,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmButton: {
    marginHorizontal: 15,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
  },
  goBackButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
  },
  continueButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'left',
    paddingHorizontal: 0,
    paddingVertical: 2,
    marginHorizontal: 10,
  },
  text: {
    paddingLeft: 8,
    paddingTop: 9,
  },
  question: {
    flex: 1,
  },
  noQuestionsText: {
    color: 'rgba(255,255,255,0.45)',
    fontFamily: 'RobotoMono',
    fontSize: 20,
    alignSelf: 'center',
    margin: '15%'
  }
});
