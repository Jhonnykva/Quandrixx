import React, {useState, useEffect} from 'react';
import { View, StyleSheet, Text, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {ProgressBar, Paragraph, Snackbar, Surface, Button} from 'react-native-paper';
import {myStyles, gradientColors, snackbarColors} from '../utils/myStyles'
import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { MaterialIcons } from '@expo/vector-icons';

export default function ProgressBarScreen({ navigation }) {

  const [progress, setProgress] = useState(0.1);
  const [algebraProgress, setAlgebraProgress] = useState(0);
  const [geometryProgress, setGeometryProgress] = useState(0);
  const [calculusProgress, setCalculusProgress] = useState(0);

  const countHowManyQuestionsWrong = (type, wrongQuestions) => {
    return wrongQuestions.filter(item => item.includes(type)).length;
  }

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;
    get(child(dbRef, 'estudantes/' + uid )).then( (student) => {
      if('questoes' in student.val()){
        const studentQuestions = student.val().questoes
        let wrongQuestions = [];     
        if('questoesErradas' in student.val()){
          wrongQuestions = student.val()["questoesErradas"]
        }
        console.log(studentQuestions["algebra"])
        get(child(dbRef, 'questoes')).then((allQuestions) => {
          if('algebra' in studentQuestions){
            setAlgebraProgress(
              (studentQuestions.algebra.facil.length + 
              studentQuestions.algebra.medio.length +
              studentQuestions.algebra.dificil.length -
              countHowManyQuestionsWrong('algebra', wrongQuestions)) / 
              (allQuestions.val().algebra.facil.length +
              allQuestions.val().algebra.medio.length +
              allQuestions.val().algebra.dificil.length)
            )
          } 
          if('geometria' in studentQuestions){
            setGeometryProgress(
              (studentQuestions.geometria.facil.length + 
              studentQuestions.geometria.medio.length +
              studentQuestions.geometria.dificil.length- 
              countHowManyQuestionsWrong('geometria', wrongQuestions)) / 
              (allQuestions.val().geometria.facil.length +
              allQuestions.val().geometria.medio.length +
              allQuestions.val().geometria.dificil.length)
            )
          }
          if('funcoes' in studentQuestions){
            setCalculusProgress(
              (studentQuestions.funcoes.facil.length + 
              studentQuestions.funcoes.medio.length +
              studentQuestions.funcoes.dificil.length -
              countHowManyQuestionsWrong('funcoes', wrongQuestions)) / 
              (allQuestions.val().funcoes.facil.length +
              allQuestions.val().funcoes.medio.length +
              allQuestions.val().funcoes.dificil.length)
            )
          }  
        }).catch((error) => {
          console.log("Error retrieving information from database!");
        })
        }

    }).catch((error) => {
      console.log("Error retrieving from Firebase!");
    })
  }, [auth.currentUser, dbRef]);

  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <Surface style={styles.content} elevation={0}>
          <View>
            <Text style={myStyles.header} variant="displayLarge">Barras de Progresso</Text>
            <View style={styles.row}>
            <Paragraph style={styles.progressBarText}>Álgebra: {(algebraProgress*100).toFixed(2)} %</Paragraph>
            <ProgressBar
              progress={algebraProgress}
              visible={true}
              color={'#E813E8'}
              style={styles.progressBar}
            />
            </View>
            <View style={styles.row}>
            <Paragraph style={styles.progressBarText}>Geometria: {(geometryProgress*100).toFixed(2)} %</Paragraph>
            <ProgressBar
              progress={geometryProgress}
              visible={true}
              color={'red'}
              style={styles.progressBar}
            />
            </View>
            <View style={styles.row}>
            <Paragraph style={styles.progressBarText}>Funções: {(calculusProgress*100).toFixed(2)} %</Paragraph>
            <ProgressBar
              progress={calculusProgress}
              visible={true}
              color={'orange'}
              style={styles.progressBar}
            />
            </View>
          </View>
          <Button style={styles.button} onPress={handleGoBack}
              icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'white'} />
              )}>
              <Text style={styles.buttonText}>Voltar</Text>
          </Button>
        </Surface>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    width: '80%',
    paddingVertical:30,
    paddingHorizontal: 20,
    marginHorizontal:'auto',
    marginVertical: 30,
    borderRadius: 15,
    alignContent: 'center',
    justifyContent: 'space-between'
  },
  row: {
    marginVertical: 10,
  },
  progressBar: {
    height: 20,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.4)',
  },
  progressBarText :{
    color: 'white',
    fontFamily: 'RobotoMono',
  },
  button: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 8,
    paddingVertical: 0,
    width:'100%',
    alignItems: 'center',
    marginBottom: 10,
    borderColor: 'black',
    borderWidth: 0.3,
    alignSelf: 'auto',
  },
  buttonText: {
    fontSize: 16,
    color: 'white',
  },
});
