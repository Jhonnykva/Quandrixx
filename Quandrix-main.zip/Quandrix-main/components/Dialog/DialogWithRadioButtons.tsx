import * as React from 'react';
import { PureComponent } from 'react';
import { ScrollView, View, StyleSheet, Image, FlatList } from 'react-native';
import {
  Button,
  Portal,
  Dialog,
  RadioButton,
  TouchableRipple,
} from 'react-native-paper';
import { TextComponent } from './DialogTextComponent';
import { countries, countryFlags } from '../../utils/countries';

type Props = {
  visible: boolean;
  close: () => void;
  registerAnswer: (country: String, countryFlag: String) => void;
};

type State = {
  checked: number;
};

type DialogItemProps = {
  item: string;
  index: number;
  checked: number;
  handlePress: () => void;
};

class DialogItem extends PureComponent<DialogItemProps> {
  render() {
    const { item, index, checked, handlePress } = this.props;

    return (
      <TouchableRipple onPress={handlePress}>
        <View style={styles.row}>
          <RadioButton
            value={index.toString()}
            status={checked === index ? 'checked' : 'unchecked'}
          />
          <TextComponent isSubheading style={styles.text}>
            {item}
          </TextComponent>
          <Image source={countryFlags[item]} style={styles.image} />
        </View>
      </TouchableRipple>
    );
  }
}

const MemoizedDialogItem = React.memo(DialogItem);

class DialogWithRadioBtns extends PureComponent<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      checked: 0,
    };
  }

  renderItem = ({ item, index }) => {
    const handlePress = () => this.setState({ checked: index });

    return <MemoizedDialogItem item={item} index={index} checked={this.state.checked} handlePress={handlePress} />;
  };

  render() {
    const { visible, close, registerAnswer } = this.props;

    return (
      <Portal>
        <Dialog onDismiss={close} visible={visible} style={styles.dialog}>
          <Dialog.Title>Escolha um país</Dialog.Title>
          <FlatList
            data={countries}
            keyExtractor={(item) => item}
            renderItem={this.renderItem}
          />
          <Dialog.Actions>
            <Button onPress={close}>Fechar</Button>
            <Button
              onPress={() =>
                registerAnswer(
                  countries[this.state.checked],
                  countryFlags[countries[this.state.checked]]
                )
              }
            >
              Aplicar
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    );
  }
}

export default DialogWithRadioBtns;

const styles = StyleSheet.create({
  container: {
    maxHeight: '80%',
    paddingHorizontal: 0,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  text: {
    paddingLeft: 0,
    fontSize: 14,
  },
  image: {
    width: 51,
    height: 30,
  },
  dialog: {
    maxHeight: '80%',
  },
});
