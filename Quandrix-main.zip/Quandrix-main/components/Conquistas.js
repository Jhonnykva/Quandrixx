import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import {myStyles, gradientColors} from '../utils/myStyles';
import {Surface, Button} from 'react-native-paper';

import {app, dbRef, auth} from '../firebase/config'
import {get, child} from "firebase/database";

export default function ConquistasScreen({ navigation }) {


  const [achievements, setAchievements] = useState({});
  const [achievementsState, setAchievementsState] = useState({});

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }
    
    const uid = auth.currentUser.uid;
      
    get(child(dbRef, 'conquistas')).then( (snapshot) => {
      if(snapshot.exists()){
        setAchievements(snapshot.val());
      }
      else {
        setAchievements({});
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })

    get(child(dbRef, 'estudantes/' + uid + '/conquistas')).then( (snapshot) => {
      if(snapshot.exists()){
        setAchievementsState(snapshot.val());
      }
      else {
        setAchievementsState({});
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
  }, [auth.currentUser, dbRef]);

  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        <View style={styles.content}>
        <Text style={[myStyles.header,{alignSelf: 'center', marginBottom: '5%'}]} variant="displayLarge">Conquistas</Text>
          <Button style={styles.goBackButton} onPress={handleGoBack}
          icon={({ size, color }) => (
                <MaterialIcons name="undo"  size={size} color={'white'} />
              )}>
            <Text style={styles.goBackText}>Voltar</Text>
          </Button>
          <ScrollView style={styles.scrollView}>
          {Object.keys(achievements).map((key, index) => (
              <Surface key={index} style={[styles.achievementContainer, { backgroundColor: achievementsState[index] ? '#F7F7A4' : '#CCCCCC' }]}
                        elevation = {4}>
                <Text style={styles.achievementTitle}>Conquista #{index} {achievementsState[index] ? '🏆' : '❔'}</Text>
                <Text style={styles.achievementDescription}>{achievements[key]["descrição"]}</Text>
              </Surface>
            ))}
          </ScrollView>
        
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  scrollView: {
    flex: 1,
    marginBottom: 20,
  },
  achievementContainer: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  achievementTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  achievementDescription: {
    fontSize: 16,
    fontFamily: 'RobotoMono',
  },
  goBackButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 4,
    alignItems: 'center',
    marginBottom: 15,
  },
  goBackText: {
    fontSize: 16,
    color: 'white',
  },
});
