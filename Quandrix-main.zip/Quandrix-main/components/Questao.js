import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradientColors} from '../utils/myStyles'
import {Button, Text, Provider, Surface, ActivityIndicator, Snackbar} from 'react-native-paper'
import { MaterialIcons } from '@expo/vector-icons';
import { colorThemes } from '../utils/index'

import {app, dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage';

import { 
  QuestionContainer, 
  OptionAnswerContainer, 
  TextAnswerContainer, 
  RightAnswerFeedback, 
  WrongAnswerFeedback 
} from '../utils/QuestionComponents';

import { activateOffensive, checkOffensiveStatus } from '../utils/offensive';
import { checkDoubleReward } from '../utils/doubleReward';
import { initializeAchievements, checkAchievements } from '../utils/achievements';
import { questionsToAdvance } from '../utils/constants';

export default function QuestionScreen({route, navigation }) {
  const { module, level } = route.params;
  const [question, setQuestion] = useState(null);
  const options = ['A', 'B', 'C', 'D', 'E'];
  const [correctAnswer, setCorrectAnswer] = useState(null);
  const [questionId, setQuestionId] = useState(null);
  const [student, setStudent] = useState({});
  const [noQuestions, setNoQuestions] = useState(false);
  const [questionType, setQuestionType] = useState("fechada");

  const [userAnswer, setUserAnswer] = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [rightAnswer, setRightAnswer] = useState(null);

  const [doubleRewardActive, setDoubleRewardActive] = useState(false);
  const [offensiveValue, setOffensiveValue] = useState(0);
  const [offensiveStatus, setOffensiveStatus] = useState(null);

  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [questionCounter, setQuestionCounter] = useState(0);

  const countHowManyQuestionsWrong = (type, wrongQuestions) => {
    return wrongQuestions.filter(item => item.includes(type)).length;
  }

  useEffect(() => {
    if(auth.currentUser === null){
      console.log('Error: null user');
      return;
    }

    const uid = auth.currentUser.uid;

    console.log(module);
    console.log(level);

    get(child(dbRef, 'estudantes/' + uid )).then( (snapshot) => {
      if(snapshot.exists()){
        setStudent(snapshot.val()); 
        console.log(snapshot.val().questoes[module][level]);
        const questionsAnswered = snapshot.val().questoes[module][level];
        get(child(dbRef, 'questoes/' + module + '/' + level)).then( (snapshot2) => {
          if(snapshot2.exists()){
            console.log(snapshot2.val())
            const filteredList = snapshot2.val().filter((_,index) => !questionsAnswered.includes(index));
            if(filteredList.length === 0){
              setNoQuestions(true);
              setQuestion(" ");
              return;
            }
            const randomIndex = Math.floor(Math.random() * filteredList.length);
            const randomElement = filteredList[randomIndex];
            console.log(randomElement);
            console.log(randomIndex);
            const stRef1 = storageRef(getStorage(app), 'questoes/' + module + '/' + level + '/' + randomElement.id + '.PNG');
            getDownloadURL(stRef1).then((url) => {
              setQuestion(url);
              setCorrectAnswer(randomElement.resposta);
              setQuestionId(randomElement.id);
              setQuestionType(randomElement.tipo);
              initializeAchievements("questao", level, module, snapshot.val());
            }).catch((error) => {
              console.log("Error: downloading image!");
              console.error(error.code);
            })
          }
          else {
            console.log("Error: snapshot doesn't exists!");
          }
        }).catch((error) => {
          console.log("Error retrieving information from database!");
        })   
        
      }
      else {
        console.log("Error: snapshot doesn't exists!");
      }
    }).catch((error) => {
      console.log("Error retrieving from Firebase!");
    })
  }, [auth.currentUser, dbRef, questionCounter]);

  useEffect(() => {
    const fetchDoubleReward = async () => {
      const result = await checkDoubleReward();
      setDoubleRewardActive(result);
    };
    fetchDoubleReward();
  }, [questionCounter]);

  useEffect(() => {
    const fetchOffensive = async () => {
      const {value, status} = await checkOffensiveStatus();
      if(status === 'Restorable'){
        setOffensiveValue(0);
      }
      else {
        setOffensiveValue(value);
      }
      setOffensiveStatus(status);
      console.log(status);
    };
    fetchOffensive();
  }, [questionCounter]);

  const handleConfirm = () => {

    if(auth.currentUser === null){
      console.error("Error: null user!");
      return;
    }
    
    const uid = auth.currentUser.uid;
    const updates = {};

    const allQuestions = student.questoes[module][level].concat((parseInt(questionId)));
    updates['/estudantes/' + uid + '/questoes/' + module + '/' + level] = allQuestions;

    if (userAnswer === correctAnswer) {
      setRightAnswer(true);
      if(doubleRewardActive){
        updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 4);
      }
      else {
        updates['/estudantes/' + uid + '/moedas'] = (student.moedas + 2);
      }

      if(offensiveStatus === 'Refillable'){
        activateOffensive(offensiveValue + 1);
      }
      else if (offensiveStatus === 'Expired' || offensiveStatus === 'Restaurable'){
        activateOffensive(1);
      }
      
      const checkAchiev = async () => {
        const achievementsStatus = await checkAchievements();
        setSnackbarVisible(achievementsStatus);
      }
      checkAchiev();
      
      if(level === "facil"){
        if(!student["dificuldades"][module]["medio"]){
          if((student["questoes"][module][level].length - countHowManyQuestionsWrong((module + '/' + level), student["questoesErradas"])) === questionsToAdvance - 1){
            updates['/estudantes/' + uid + '/dificuldades/' + module + '/medio'] = true;
          }
        }
      }
      if(level === "medio"){
        if(!student["dificuldades"][module]["dificil"]){
          if((student["questoes"][module][level].length - countHowManyQuestionsWrong((module + '/' + level), student["questoesErradas"])) === questionsToAdvance - 1){
            updates['/estudantes/' + uid + '/dificuldades/' + module + '/dificil'] = true;
          }
        }
      }

    } else {
      setRightAnswer(false);
      const wrongQuestionPath = 'questoes/' + module + '/' + level + '@' + (parseInt(questionId));
      if('questoesErradas' in student){
        const wrongQuestions = student.questoesErradas.concat(wrongQuestionPath);
        updates['/estudantes/' + uid + '/questoesErradas'] = wrongQuestions;
      }
      else{
        updates['/estudantes/' + uid + '/questoesErradas'] = [wrongQuestionPath];
      } 
    }
    
    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      setSuccessfulRegister(false);
      setSnackbarMessage("Erro ao atualizar o banco de dados!");
    })

    setConfirmed(true);

    if(!student.vip){
      navigation.navigate('Ad');
    }
  };

  const handleGoBack = () => {
    navigation.goBack();
  }

  const handleContinue =() => {
    setUserAnswer(null);
    setConfirmed(false);
    setRightAnswer(null);
    setNoQuestions(false);
    setCorrectAnswer(null);
    setQuestion(null);
    setQuestionCounter(questionCounter + 1);
  }

  return (
    <Provider theme={
    rightAnswer === null
      ? colorThemes['blue']['light']
      : rightAnswer === true
      ? colorThemes['green']['light']
      : colorThemes['red']['light']
    }>
      <LinearGradient
        colors={gradientColors}
        style={styles.background}
      >
        {(!noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <QuestionContainer 
            question={question} 
            confirmed={confirmed} 
            rightAnswer={rightAnswer} 
          />
          {doubleRewardActive && 
            <Text style={{textAlign: 'right', marginRight: '5%', color: 'yellow', fontFamily: 'Orbitron'}}>2X Moedas‼️</Text>
          }
          {questionType === "fechada" && 
            <OptionAnswerContainer 
              confirmed={confirmed} 
              options={options} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {questionType === "aberta" && 
            <TextAnswerContainer 
              confirmed={confirmed} 
              setUserAnswer={setUserAnswer}
              rightAnswer={rightAnswer}
              userAnswer={userAnswer}
            />
          }
          {rightAnswer === true && 
            <RightAnswerFeedback 
              doubleRewardActive={doubleRewardActive}
              baseCoinReward={2}
              progress={true}  
            />
          }
          {rightAnswer === false && 
            <WrongAnswerFeedback
              auxiliarText={"Refaça a questão no menu inicial!"}
            />
          }
          {(userAnswer!=null && confirmed === false) &&
          <Button
              mode="contained-tonal"
              buttonColor={"#66FF66"}
              onPress={handleConfirm}
              style={styles.confirmButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="done" size={size} color={color} />
              )}
          >
            Confirmar
          </Button>  }
          {confirmed === true && <View style={styles.row}>
            <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleContinue}
              style={styles.continueButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="play-arrow" size={size} color={color} />
              )}
          >
            Continuar
          </Button>  
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={styles.goBackButton}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
          </View>
          }
        </Surface> }
        {(noQuestions && question) && <Surface style={styles.container} elevation={0}>
          <Text style={styles.noQuestionsText}>
            Opa, parece que você já completou todas as questões dessa dificuldade e desse módulo.
            Tente uma dificuldade mais alta, um novo módulo, ou espere por mais questões.
          </Text>
          <Button
              mode="contained-tonal"
              buttonColor={"#17B0E0"}
              onPress={handleGoBack}
              style={[styles.goBackButton, {alignSelf: 'center'}]}
              labelStyle={styles.buttonText}
              icon={({ size, color }) => (
                <MaterialIcons name="undo" size={size} color={color} />
              )}
          >
            Voltar
          </Button>
        </Surface>}
        {(!question) && <Surface style={styles.container} elevation={0}>
          <ActivityIndicator animating={true} size='large'/>
        </Surface>}
      </LinearGradient>
      <Snackbar
          visible={snackbarVisible}
          onDismiss={() => setSnackbarVisible(false)}
          action={{
            label: 'Fechar',
            onPress: () => {
              setSnackbarVisible(false)
            },
          }}
          duration={Snackbar.DURATION_MEDIUM}
          style={{backgroundColor: '#F2F261'}}
          theme={colorThemes['yellow']['dark'] }
        >
          <Text>Conquista Desbloqueada! 🏆</Text>
      </Snackbar>
    </Provider>
  );
}

const styles = StyleSheet.create({
 container: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: '85%',
    height: '85%',
    paddingTop:20,
    paddingBottom:20,
    marginHorizontal:'auto',
    marginVertical:'auto',
    borderRadius: 15,
    justifyContent: 'center',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmButton: {
    marginHorizontal: 15,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
  },
  goBackButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
  },
  continueButton: {
    marginHorizontal: 5,
    marginBottom:0,
    paddingVertical: 0,
    borderRadius: 8,
    alignItems: 'center',
    width: '45%',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'left',
    paddingHorizontal: 0,
    paddingVertical: 2,
    marginHorizontal: 10,
  },
  text: {
    paddingLeft: 8,
    paddingTop: 9,
  },
  question: {
    flex: 1,
  },
  noQuestionsText: {
    color: 'rgba(255,255,255,0.45)',
    fontFamily: 'RobotoMono',
    fontSize: 20,
    alignSelf: 'center',
    margin: '15%'
  }
});
