import { StyleSheet } from 'react-native';

export const myStyles = StyleSheet.create({
  labels: {
    fontSize: 18,
    marginBottom: 10,
    fontFamily: 'RobotoMono', 
    color: 'white',
    alignContent: 'center',
    justifyContent: "center",
    alignItems: "center",
  },
  title:{
    fontFamily: 'RobotoMono', 
    fontSize: 25, 
    color: 'white',
  },
  header:{
    fontFamily:'Orbitron',
    fontSize: 40,
    color: 'white',
    textDecorationLine: 'underline',
  }
});

export const gradientColors = ['#004690', '#1CE0B5'];

export const snackbarColors = {'success' : '#B5F7CB', 'error' : '#F7B5C5'};