import React from 'react';
import { View, StyleSheet, ScrollView, Image } from 'react-native';
import { TouchableRipple, RadioButton, Text, TextInput} from 'react-native-paper'

export const QuestionContainer = ({confirmed, rightAnswer, question}) => {
  return (
    <View style={[styles.questionContainer, {borderWidth : confirmed ? 2 : 0}, 
      {borderColor: rightAnswer ? 'green' : 'red'}]}>
        { question &&
        <Image
          style={styles.question}
          source={{uri: question}}
          resizeMode='contain'
        />
      }
    </View>
  )
}

export const OptionAnswerContainer = ({confirmed, options, setUserAnswer, rightAnswer, userAnswer}) => {
  return(
    <ScrollView style={confirmed ? styles.singleOption : styles.optionsContainer}>
      <View>
        {options.map((option, index) => (
        <TouchableRipple onPress={() => setUserAnswer(option)} disabled={confirmed}>
          <View style={styles.row}>
            {(rightAnswer === null || userAnswer === option) && <View pointerEvents="none">
              <RadioButton
                value= {index}
                status={userAnswer === option ? 'checked' : 'unchecked'}
                disabled={confirmed}
              />
            </View>}
            {(rightAnswer === null || userAnswer === option) && <Text style={styles.text}>
              {option}
            </Text> }
          </View>
        </TouchableRipple>
        ))}
      </View>
    </ScrollView>
  )
}

export const TextAnswerContainer = ({confirmed, rightAnswer, setUserAnswer, userAnswer}) => {
  return (
    <View style={[styles.answerContainer, {borderWidth : confirmed ? 2 : 0}, 
      {borderColor: rightAnswer ? 'green' : 'red'}]}>
        <TextInput
          style={styles.answerInput}
          placeholder="Insira sua resposta aqui"
          onChangeText={(text) => setUserAnswer(text)}
          value={userAnswer}
          disabled={confirmed}
        />
    </View>
  );
}

export const RightAnswerFeedback = ({doubleRewardActive, baseCoinReward, progress}) => {
  return (
    <View style={[styles.feedbackContainer, 
      {borderColor: 'green'}]}>
          <Text style={styles.correctText}>Resposta Certa {String.fromCodePoint(0x2705)}</Text>
          {doubleRewardActive  
            ? <Text style={styles.correctText}>+ {baseCoinReward*2} Moedas {String.fromCodePoint(0x1FA99)}</Text>
            : <Text style={styles.correctText}>+ {baseCoinReward} Moedas {String.fromCodePoint(0x1FA99)}</Text>
          }
          {progress && <Text style={styles.correctText}>+ 1 de Progresso</Text>}
    </View>
  );
}

export const WrongAnswerFeedback = ({auxiliarText}) => {
  return (
    <View style={[styles.feedbackContainer, 
      {borderColor: 'red'}]}>
          <Text style={styles.wrongText}> Resposta Errada {String.fromCodePoint(0x274C)}</Text>
          {auxiliarText && <Text style={styles.wrongText}>{auxiliarText}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  questionContainer: {
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.4)',
    padding: 0,
    marginHorizontal: 20,
    marginTop: 0,
    marginBottom: 10,
    borderRadius: 8,
    flex: 2,
  },
  optionsContainer: {
    marginBottom: 1,
    flex: 1,
  },
  singleOption: {
    marginBottom: 1,
    flex:0.2,
  },
  answerContainer: {
    marginHorizontal: 20,
    marginBottom: 4,
    padding: 0,
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderRadius: 8,
  },
  answerInput: {
    fontSize: 16,
    padding: 0,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  feedbackContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.4)',
    borderWidth: 2,
    marginHorizontal: 20,
    marginTop: 0,
    marginBottom: 15,
    borderRadius: 8,
    minHeight: 10,
    paddingVertical: 10,
  },
  correctText:{
    fontSize: 20,
    color: 'green',
  },
  wrongText:{
    fontSize: 20,
    color: 'red',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'left',
    paddingHorizontal: 0,
    paddingVertical: 2,
    marginHorizontal: 10,
  },
  text: {
    paddingLeft: 8,
    paddingTop: 9,
  },
  question: {
    flex: 1,
  },
});
