import AsyncStorage from '@react-native-async-storage/async-storage';


const offensiveTimeCycle = 24;

export async function createOffensiveIfInexistent() {
  const createOffensive = async () => {
    const storedItem = await AsyncStorage.getItem('offensive');
    if (storedItem) {
    }
    else {
      const expirationTimeInHours = offensiveTimeCycle*2;
      const expirationTimestamp = Date.now() + expirationTimeInHours * 60 * 60 * 1000;
      AsyncStorage.setItem('offensive', JSON.stringify({value: 0, expiration: expirationTimestamp})).then(() => {
        console.log("Ofensiva guardada!");
      }).catch((error) => {
        console.error("Error ao usar o AsyncStorage");
        return;
      })
    }
  };

  createOffensive();
}

export async function checkOffensiveStatus() {
  const checkExpiration = async () => {
    const storedItem = await AsyncStorage.getItem('offensive');
    if (storedItem) {
      const { value, expiration } = JSON.parse(storedItem);
      const currentTimestamp = Date.now();
      const timeDifference = expiration - currentTimestamp;
      console.log(timeDifference);
      if(timeDifference <= 0){
        const updatedItem = { value: 0, expiration: currentTimestamp };
        await AsyncStorage.setItem('offensive', JSON.stringify(updatedItem)); 
        return { 
          value: 0,
          status: "Expired",
        }
      }
      else if (timeDifference < offensiveTimeCycle * 60 * 60 * 1000){
        return {
          value: value,
          status: "Restorable",
        }
      }
      else if (timeDifference < offensiveTimeCycle * 2 * 60 * 60 * 1000){
        return {
          value: value,
          status: "Refillable",
        }
      }
      else {
        return {
          value: value,
          status: "Active",
        }
      }
    }
    else {
      console.log("Erro: item não existe no Storage");
    }
  };
  return checkExpiration();
}

export async function activateOffensive(newValue) {
  const changeOffensive = async () => {
    const expirationTimeInHours = offensiveTimeCycle * 3;
    const expirationTimestamp = Date.now() + expirationTimeInHours * 60 * 60 * 1000;
    const updatedItem = { value: newValue, expiration: expirationTimestamp };
    await AsyncStorage.setItem('offensive', JSON.stringify(updatedItem));
  };
  changeOffensive();
}