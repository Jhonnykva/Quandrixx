import AsyncStorage from '@react-native-async-storage/async-storage';

export async function checkDoubleReward() {
  const checkExpiration = async () => {
    const storedItem = await AsyncStorage.getItem('doubleReward');
    if (storedItem) {
      const { value, expiration } = JSON.parse(storedItem);
      const currentTimestamp = Date.now();

      return currentTimestamp <= expiration;
    }
    return false;
  };

  return checkExpiration();
}