import { useState } from "react"
import AsyncStorage from '@react-native-async-storage/async-storage';
import {dbRef, auth} from '../firebase/config'
import {get, child, update} from "firebase/database";


let achievementsDict = {
  "10_in_a_day": false,
  "hard_in_less_than_a_minute": false,
  "all_exercises_of_a_module": false
}

let infoDict = {
  startTimestamp: null,
  type: null,
  level: null,
  module: null,
  student: null,
}

const countHowManyQuestionsWrong = (type, wrongQuestions) => {
  return wrongQuestions.filter(item => item.includes(type)).length;
}

async function createQuestionsDoneToday() {
  const createQuestions = async () => {
    const storedItem = await AsyncStorage.getItem('questionsDoneToday');
    if (storedItem) {
      const { value, day } = JSON.parse(storedItem);
      const today = new Date();
      const parsedDay = new Date(day);
      const isSameDay =
        today.getFullYear() === parsedDay.getFullYear() &&
        today.getMonth() === parsedDay.getMonth() &&
        today.getDate() === parsedDay.getDate();
      if(!isSameDay){
        AsyncStorage.setItem('questionsDoneToday', JSON.stringify({value: 0, day: today})).then(() => {
          console.log("questionsDoneToday atualizado!");
        }).catch((error) => {
          console.error("Error ao usar o AsyncStorage");
          return;
        })
      }
    }
    else {
      AsyncStorage.setItem('questionsDoneToday', JSON.stringify({value: 0, day: new Date()})).then(() => {
        console.log("questionsDoneToday guardado!");
      }).catch((error) => {
        console.error("Error ao usar o AsyncStorage");
        return;
      })
    }
  };

  createQuestions();
}

export const initializeAchievements = (type, level, module, student) => {
  
  infoDict.student = student;
  infoDict.level = level;
  infoDict.module = module;
  infoDict.type = type;

  if(type === "questao"){
    if(level === "dificil"){
      achievementsDict["hard_in_less_than_a_minute"] = true;
    }
    achievementsDict["all_exercises_of_a_module"] = true
    achievementsDict["10_in_a_day"] = true
  }

  if(achievementsDict["10_in_a_day"]){
    if(!student.conquistas[0]){
      createQuestionsDoneToday();
    }
    else{
      achievementsDict["10_in_a_day"] = false;
    }
  }
  if(achievementsDict["hard_in_less_than_a_minute"]){
    if(!student.conquistas[1]){
      infoDict.startTimestamp = Date.now();
    }
    else{
      achievementsDict["hard_in_less_than_a_minute"] = false;
    }
  }
  if(achievementsDict["all_exercises_of_a_module"]){
    if(!student.conquistas[1]){
      //pass;
    }
    else{
      achievementsDict["all_exercises_of_a_module"] = false;
    }
  }
  
}

export const checkAchievements = async () => { 

  if(auth.currentUser === null){
    console.error("Error: null user!");
    return;
  }
  
  const uid = auth.currentUser.uid;

  let achievementsStatus = false;
  const updates = {};
  if(achievementsDict["10_in_a_day"]){
    const storedItem = await AsyncStorage.getItem('questionsDoneToday');
    if (storedItem) {
      const { value, day } = JSON.parse(storedItem);
      if(value === 9){
        console.log("10_in_a_day");
        updates['/estudantes/' + uid + '/conquistas/' + '0' ] = true;
        achievementsStatus = true;
      }
      const updatedItem = { value: value + 1, day: day };
      await AsyncStorage.setItem('questionsDoneToday', JSON.stringify(updatedItem));
    }
    else {
      console.log("Erro: item não existe no Storage");
    }
  }
  if(achievementsDict["hard_in_less_than_a_minute"]){
    const endTimestamp = Date.now();
    if(endTimestamp - infoDict.startTimestamp < (1000 * 60)){
      console.log("hard_in_less_than_a_minute");
      updates['/estudantes/' + uid + '/conquistas/' + '1' ] = true;
      achievementsStatus = true;
    }
  }
  if(achievementsDict["all_exercises_of_a_module"]){
    await get(child(dbRef, 'questoes')).then((allQuestions) => {
      const module = infoDict.module;
      const student = infoDict.student;
      const numberOfTotalQuestions = 
        allQuestions.val()[module].facil.length +
        allQuestions.val()[module].medio.length +
        allQuestions.val()[module].dificil.length;
      const questionsDone = 
        student["questoes"][module].facil.length +
        student["questoes"][module].medio.length +
        student["questoes"][module].dificil.length -
        countHowManyQuestionsWrong(module, student["questoesErradas"]);
      if(questionsDone + 1  === numberOfTotalQuestions){
        console.log("all_exercises_of_a_module");
        updates['/estudantes/' + uid + '/conquistas/' + '2' ] = true;
        achievementsStatus = true;
      }
    }).catch((error) => {
      console.log("Error retrieving information from database!");
    })
  }

  if(updates){
    update(dbRef, updates).then( (update) => {
    }).catch((error) => {
      console.log("Error updating on Firebase!");
    })
  }

  return achievementsStatus;
}