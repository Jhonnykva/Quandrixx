import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const CountdownButton = ({onClose}) => {
  const [countdown, setCountdown] = useState(5);
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    const countdownInterval = setInterval(() => {
      setCountdown((prevCountdown) => prevCountdown - 1);
    }, 1000);

    const showButtonTimeout = setTimeout(() => {
      clearInterval(countdownInterval);
      setShowButton(true);
    }, 5000);

    return () => {
      clearInterval(countdownInterval);
      clearTimeout(showButtonTimeout);
    };
  }, []);

  return (
    <View style={styles.container}>
      {showButton ? (
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <Text style={styles.closeButtonText}>X</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.countdownContainer}>
          <Text style={styles.countdownText}>{countdown}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  countdownContainer: {
    borderRadius: 50,
    backgroundColor: 'lightblue',
    padding: 10,
    paddingHorizontal: 18
  },
  countdownText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  closeButton: {
    borderRadius: 50,
    backgroundColor: 'red',
    padding: 10,
    paddingHorizontal: 18
  },
  closeButtonText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
});

export default CountdownButton;
